using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace F2R.EditorTools
{
    public static class F2RImportAudit
    {
        public static string Data()
        {
            var b = QuestionBank.Load(); var errors = new List<string>();
            void Check(bool ok, string message) { if (!ok) errors.Add(message); }
            Check(b.Count == 543, "Expected 543 items"); Check(b.problems.Count == 0, string.Join("\n", b.problems));
            Check(b.chapters.Count == 18, "18 chapters"); Check(b.byId.Values.Select(q=>q.groupId).Distinct().Count()==117, "117 groups");
            Check(!b.chapters.Any(c=>c.number>=25 && c.number<=28 || c.number==42), "Unavailable chapters invented");
            Check(b.byId.ContainsKey("21-5-insert") && b.byId.ContainsKey("21-5-vocab-③"), "Duplicate 21-5 distinction");
            Check(b.GetChapter(31).questions.Count==32 && b.byId.ContainsKey("31-9-3-A"), "Preserved chapter31 IDs");
            foreach (var q in b.byId.Values)
            {
                Check(!string.IsNullOrWhiteSpace(q.explanation), q.id+" explanation");
                Check(!string.IsNullOrWhiteSpace(q.answerDisplay), q.id+" key");
                if (q.kind==QKind.Short) Check(q.accepted.Count>0 && !string.IsNullOrEmpty(q.modelAnswer),q.id+" input key");
                if (q.kind==QKind.Descriptive) Check(!string.IsNullOrEmpty(q.modelAnswer),q.id+" model");
                if (q.kind==QKind.Choice || q.kind==QKind.Insert || q.kind==QKind.PickNumber || q.kind==QKind.Judge || q.kind==QKind.TrueFalse)
                    Check(q.correctIndex>=0 && q.correctIndex<q.options.Count,q.id+" correct index");
                if (q.kind==QKind.Order) Check(q.correctOrder.OrderBy(x=>x).SequenceEqual(Enumerable.Range(0,q.orderParas.Count)),q.id+" order");
                if (q.optionMarkers!=null) Check(q.optionMarkers.All(x=>x!=null),q.id+" marker mapping");
                if (q.target!=null && q.target.type==SegType.Bracket) Check(q.target.answer!=null,q.id+" bracket answer");
                if (q.kind==QKind.Short && q.target!=null && q.target.type==SegType.Marker) Check(q.target.answer==q.modelAnswer,q.id+" correction target");
            }
            Check(!PassageRenderer.PlainBox(b.byId["22-5-1"]).Contains("are they simply"), "22-5 printed answer exposed");
            Check(!PassageRenderer.PlainBox(b.byId["29-8-1"]).Contains("does it even mean"), "29-8 printed answer exposed");
            var fixture = new SaveData {totalXP=200,records=new List<ItemRecord>{ new ItemRecord{id="21-5-insert",attempts=1,firstResult=1,lastResult=1} },notebook=new List<string>{"40-5-3-②"}};
            var code = Storage.Export(fixture); Check(Storage.TryImport(code,b,out var restored,out var error),"Recovery "+error);
            Check(restored!=null && restored.totalXP==200 && restored.records[0].id==fixture.records[0].id,"Recovery roundtrip");
            Check(!Storage.TryImport("F2R1:invalid",b,out _,out _),"Invalid recovery accepted");
            File.WriteAllText("Verification/data-audit.txt",$"Items={b.Count}; Groups=117; Passages=18\n"+string.Join("\n", b.chapters.Select(c=>$"{c.number}: {c.questions.Count}"))+"\nErrors="+errors.Count+"\n"+string.Join("\n",errors));
            if(errors.Count>0) throw new Exception(string.Join("\n",errors));
            return "PASS: 543 items / 117 groups / 18 passages; keys, targets, chapter31 IDs and recovery validated";
        }

        static object Get(object obj,string name)=>obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).GetValue(obj);
        static void Call(object obj,string name,params object[] args)=>obj.GetType().GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).Invoke(obj,args);
        public static string Open(string id, int width=1600,int height=900)
        {
            var a=F2RApp.Instance;
            if(a==null) throw new Exception("Play mode required");
            F2RApp.DebugScreen=new Vector2Int(width,height); F2RApp.DebugMobile=width<1000; F2RApp.IgnoreFocus=true;
            a.clip.Skip(); a.modal.Close();
            a.save.session=new SessionState{active=true,timerSec=90,items=new List<SessionItem>{new SessionItem{id=id}}};
            a.top.SetMode(TopMode.Quiz);
            var view=new QuizView(a); a.SetView(view);view.ShowCurrent();view.Tick(0.6f);a.Relayout(true);
            Canvas.ForceUpdateCanvases();
            return id+"; " +width+"x"+height+"; state="+Get(view,"st");
        }
        public static string LayoutAudit()
        {
            var a=F2RApp.Instance;var v=a.view;
            var pass=(ScrollRect)Get(v,"passScroll");var card=(RectTransform)Get(v,"cardRt");var ans=(RectTransform)Get(v,"answerRt");
            var text=(TextMeshProUGUI)Get(v,"passText");text.ForceMeshUpdate();
            float end=card.anchoredPosition.y-card.rect.height;
            if(card.rect.height<160 || pass.viewport.rect.height<60) throw new Exception("Passage collapsed: "+card.rect.height+" viewport "+pass.viewport.rect.height);
            if(-card.anchoredPosition.y+card.rect.height>-ans.anchoredPosition.y+2)throw new Exception("Passage overlaps answer controls");
            pass.verticalNormalizedPosition=0;
            return $"PASS passage card {card.rect.width}x{card.rect.height}; viewport {pass.viewport.rect.width}x{pass.viewport.rect.height}; text height {text.preferredHeight}; glyphs {text.textInfo.characterCount}; scrollBottom={pass.verticalNormalizedPosition}";
        }
        public static string Interaction()
        {
            var a=F2RApp.Instance;var original=a.save;var reports=new List<string>();
            // Isolate actual recording from the learner's persistent progress.
            string stored=PlayerPrefs.GetString("F2R_G1_OCT_REVIEW_v1", "");
            try
            {
                a.save=new SaveData();
                foreach(var id in new[]{"21-9","22-1-5","23-5-④","33-5-2","35-1-1","32-5-1-ⓝ","37-7-3-①","40-5-4","41-2"})
                {
                    Open(id);var v=a.view;var q=a.bank.byId[id];
                    if(q.kind==QKind.Order)foreach(var i in q.correctOrder)Call(v,"Select",i);
                    else if(q.kind==QKind.Short)((TMP_InputField)Get(v,"input")).text=q.modelAnswer;
                    else if(q.kind!=QKind.Descriptive)Call(v,"Select",q.correctIndex);
                    Call(v,"OnAction");
                    if(q.kind==QKind.Descriptive)
                    {
                        if(Get(v,"st").ToString()!="SelfAssess")throw new Exception(id+" must self-assess");
                        Call(v,"Finish",Result.SelfCorrect,1f);
                    }
                    if(Get(v,"st").ToString()!="Revealed" || !a.Session.items[0].done)throw new Exception(id+" no feedback");
                    float time=(float)Get(v,"elapsed");v.Tick(5f);if((float)Get(v,"elapsed")!=time)throw new Exception(id+" revealed timer advanced");
                    if(!a.Session.active)throw new Exception(id+" auto advanced");
                    reports.Add(id+": correct locked feedback, explicit next, timer stopped");
                }
                Open("41-1-1"); var timed=a.view;a.Session.timerSec=30;
                var before=(float)Get(timed,"elapsed");a.modal.Show("test","timer pause",null,("continue",BtnStyle.Primary,null));timed.Tick(5);a.modal.Close();
                if((float)Get(timed,"elapsed")!=before)throw new Exception("Modal did not pause");
                Call(timed,"Timeout"); if(a.Session.items[0].result!=(int)Result.Unanswered || !a.Session.active)throw new Exception("Timeout result");
                reports.Add("Modal pause and unanswered timeout PASS");
            }
            finally
            {
                a.save=original;
                if(stored.Length==0)PlayerPrefs.DeleteKey("F2R_G1_OCT_REVIEW_v1");else PlayerPrefs.SetString("F2R_G1_OCT_REVIEW_v1",stored);
                PlayerPrefs.Save();
                a.ShowHome();
            }
            File.WriteAllText("Verification/play-audit.txt",string.Join("\n",reports));return string.Join("\n",reports);
        }
    }
}
