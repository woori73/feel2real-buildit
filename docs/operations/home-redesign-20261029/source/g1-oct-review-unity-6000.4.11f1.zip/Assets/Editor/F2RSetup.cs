using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.TextCore.LowLevel;

namespace F2R.EditorTools
{
    public static class F2RSetup
    {
        const string FontDir = "Assets/Resources/Fonts";
        const string ScenePath = "Assets/Scenes/F2RReview.unity";

        [MenuItem("F2R/Setup All")]
        public static string SetupAll()
        {
            var log = CreateFonts();
            log += "\n" + ConfigurePlayer();
            log += "\n" + CreateScene();
            AssetDatabase.SaveAssets();
            return log;
        }

        static TMP_FontAsset MakeFont(string ttfPath, string assetPath)
        {
            var existing = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(assetPath);
            if (existing != null) return existing;
            var font = AssetDatabase.LoadAssetAtPath<Font>(ttfPath);
            var fa = TMP_FontAsset.CreateFontAsset(font, 64, 7, GlyphRenderMode.SDFAA, 2048, 2048, AtlasPopulationMode.Dynamic, true);
            fa.name = Path.GetFileNameWithoutExtension(assetPath);
            AssetDatabase.CreateAsset(fa, assetPath);
            fa.atlasTextures[0].name = fa.name + " Atlas";
            AssetDatabase.AddObjectToAsset(fa.atlasTextures[0], fa);
            fa.material.name = fa.name + " Material";
            AssetDatabase.AddObjectToAsset(fa.material, fa);
            fa.isMultiAtlasTexturesEnabled = true;
            var so = new SerializedObject(fa);
            so.FindProperty("m_ClearDynamicDataOnBuild").boolValue = true;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(fa);
            return fa;
        }

        [MenuItem("F2R/Create Fonts")]
        public static string CreateFonts()
        {
            Directory.CreateDirectory(FontDir);
            var regular = MakeFont("Assets/Fonts/IBMPlexSansKR-Regular.ttf", FontDir + "/IBMPlexSansKR-Regular SDF.asset");
            var bold = MakeFont("Assets/Fonts/IBMPlexSansKR-Bold.ttf", FontDir + "/IBMPlexSansKR-Bold SDF.asset");
            // The full SDF shader gives cleaner small Hangul than the mobile variant.
            var sdf = Shader.Find("TextMeshPro/Distance Field");
            foreach (var fa in new[] { regular, bold }) { fa.material.shader = sdf; EditorUtility.SetDirty(fa.material); }
            regular.material.SetFloat("_FaceDilate", 0.1f);
            var table = regular.fontWeightTable;
            table[7].regularTypeface = bold;
            EditorUtility.SetDirty(regular);

            var settings = Resources.Load<TMP_Settings>("TMP Settings");
            if (settings != null)
            {
                var so = new SerializedObject(settings);
                so.FindProperty("m_defaultFontAsset").objectReferenceValue = regular;
                so.FindProperty("m_UseModernHangulLineBreakingRules").boolValue = true;
                so.ApplyModifiedPropertiesWithoutUndo();
                EditorUtility.SetDirty(settings);
            }
            AssetDatabase.SaveAssets();
            return $"fonts ok: {regular.name}, {bold.name}, settings={(settings != null)}";
        }

        [MenuItem("F2R/Configure Player")]
        public static string ConfigurePlayer()
        {
            PlayerSettings.companyName = "Feel2Real";
            PlayerSettings.productName = "고1 10월 영어 복습";
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
            PlayerSettings.WebGL.dataCaching = false;
            PlayerSettings.WebGL.threadsSupport = false;
            PlayerSettings.WebGL.decompressionFallback = false;
            PlayerSettings.runInBackground = false;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            return "player settings ok";
        }

        [MenuItem("F2R/Create Scene")]
        public static string CreateScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var cam = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
            cam.tag = "MainCamera";
            var c = cam.GetComponent<Camera>();
            c.clearFlags = CameraClearFlags.SolidColor;
            c.backgroundColor = new Color(0.02f, 0.06f, 0.17f);
            c.orthographic = true;
            new GameObject("F2R Game", typeof(F2RApp));
            EditorSceneManager.SaveScene(scene, ScenePath);
            var scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EditorBuildSettings.scenes = scenes;
            return "scene ok: " + ScenePath;
        }
    }
}
