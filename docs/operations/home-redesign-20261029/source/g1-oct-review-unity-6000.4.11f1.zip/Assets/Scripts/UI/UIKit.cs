using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace F2R
{
    public enum BtnStyle { Primary, Ghost, Chip, Danger, Option, Soft }
    public enum BtnState { Normal, Selected, Correct, Wrong, Dim }

    /// <summary>Procedural button: rounded fill, outline, glow and a TMP label.</summary>
    public class Btn
    {
        public GameObject go;
        public RectTransform rt;
        public Button button;
        public Image bg, outline, glow;
        public TextMeshProUGUI label;
        public BtnStyle style;
        public BtnState state;
        public object tag;

        public void SetState(BtnState s)
        {
            state = s;
            Color fill, edge, text;
            switch (style)
            {
                case BtnStyle.Primary: fill = Palette.Cyan; edge = Palette.CyanSoft; text = Palette.NavyDeep; break;
                case BtnStyle.Danger: fill = Palette.Coral.A(0.18f); edge = Palette.Coral; text = Palette.Coral; break;
                case BtnStyle.Soft: fill = Palette.PanelSoft; edge = Palette.EdgeSoft; text = Palette.White; break;
                default: fill = Palette.Hex("#0C2457F2"); edge = Palette.Edge.A(0.75f); text = Palette.White; break;
            }
            bool glowOn = false;
            switch (s)
            {
                case BtnState.Selected: fill = Palette.Cyan; edge = Palette.White; text = Palette.NavyDeep; glowOn = true; break;
                case BtnState.Correct: fill = Palette.Green; edge = Palette.White; text = Palette.NavyDeep; glowOn = true; break;
                case BtnState.Wrong: fill = Palette.Coral; edge = Palette.White.A(0.8f); text = Palette.NavyDeep; break;
                case BtnState.Dim: fill = fill.A(fill.a * 0.45f); edge = edge.A(0.25f); text = text.A(0.45f); break;
            }
            bg.color = fill; outline.color = edge; label.color = text;
            if (glow) { glow.enabled = glowOn; glow.color = (s == BtnState.Correct ? Palette.Green : Palette.Cyan).A(0.55f); }
        }

        public bool Interactable { get => button.interactable; set => button.interactable = value; }
        public void SetLabel(string s) { label.text = s; }
    }

    public static class UI
    {
        public static TMP_FontAsset Font;
        public static Action<string> OnSound;

        public static RectTransform Rect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            go.layer = 5;
            return (RectTransform)go.transform;
        }

        public static void Stretch(RectTransform rt, float l = 0, float t = 0, float r = 0, float b = 0)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(l, b); rt.offsetMax = new Vector2(-r, -t);
        }

        /// <summary>Positions rt in parent coordinates with a top-left origin.</summary>
        public static void Place(RectTransform rt, float x, float y, float w, float h)
        {
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1); rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, -y); rt.sizeDelta = new Vector2(w, h);
        }

        public static Image Panel(Transform parent, Color c, float radius = 18, string name = "Panel")
        {
            var rt = Rect(name, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = Art.Round; img.type = Image.Type.Sliced; img.color = c;
            img.pixelsPerUnitMultiplier = Art.R / Mathf.Max(1f, radius);
            img.raycastTarget = false;
            return img;
        }

        public static Image Outline(Transform parent, Color c, float radius = 18)
        {
            var img = Panel(parent, c, radius, "Outline");
            img.sprite = Art.Outline;
            Stretch(img.rectTransform);
            img.gameObject.AddComponent<LayoutElement>().ignoreLayout = true;
            return img;
        }

        public static Image Glow(Transform parent, Color c, float pad = 18)
        {
            var rt = Rect("Glow", parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = Art.Glow; img.type = Image.Type.Sliced; img.color = c; img.raycastTarget = false;
            img.pixelsPerUnitMultiplier = 1.4f;
            Stretch(rt, -pad, -pad, -pad, -pad);
            rt.gameObject.AddComponent<LayoutElement>().ignoreLayout = true;
            return img;
        }

        /// <summary>Glass panel with cyan outline.</summary>
        public static Image Card(Transform parent, string name, Color fill, Color edge, float radius = 18)
        {
            var img = Panel(parent, fill, radius, name);
            Outline(img.transform, edge, radius);
            return img;
        }

        public static TextMeshProUGUI Text(Transform parent, string s, float size, Color c, TextAlignmentOptions align = TextAlignmentOptions.TopLeft, bool bold = false, string name = "Text")
        {
            var rt = Rect(name, parent);
            var t = rt.gameObject.AddComponent<TextMeshProUGUI>();
            t.font = Font; t.fontSize = size; t.color = c; t.alignment = align; t.text = s;
            t.fontStyle = bold ? FontStyles.Bold : FontStyles.Normal;
            t.textWrappingMode = TextWrappingModes.Normal;
            t.raycastTarget = false;
            t.richText = true;
            rt.gameObject.AddComponent<MarkFix>();
            return t;
        }

        public static Btn Button(Transform parent, string label, float size, BtnStyle style, Action onClick, string name = "Button")
        {
            var b = new Btn { style = style };
            b.rt = Rect(name, parent);
            b.go = b.rt.gameObject;
            float radius = style == BtnStyle.Chip ? 14 : 16;
            b.glow = Glow(b.rt, Palette.Cyan.A(0.5f), 14);
            b.glow.enabled = false;
            var bgRt = Rect("Fill", b.rt); Stretch(bgRt);
            b.bg = bgRt.gameObject.AddComponent<Image>();
            b.bg.sprite = Art.Round; b.bg.type = Image.Type.Sliced; b.bg.pixelsPerUnitMultiplier = Art.R / radius;
            b.outline = Outline(b.rt, Palette.Edge, radius);
            b.label = Text(b.rt, label, size, Palette.White, TextAlignmentOptions.Center, style == BtnStyle.Primary || style == BtnStyle.Option);
            Stretch(b.label.rectTransform, 14, 4, 14, 4);
            b.button = b.go.AddComponent<UnityEngine.UI.Button>();
            b.button.targetGraphic = b.bg;
            var cb = b.button.colors;
            cb.normalColor = Color.white; cb.highlightedColor = new Color(1.12f, 1.12f, 1.12f); cb.pressedColor = new Color(0.8f, 0.8f, 0.8f);
            cb.selectedColor = Color.white; cb.disabledColor = new Color(0.55f, 0.55f, 0.6f, 0.7f); cb.colorMultiplier = 1.3f;
            b.button.colors = cb;
            var nav = b.button.navigation; nav.mode = Navigation.Mode.None; b.button.navigation = nav;
            b.button.onClick.AddListener(() => { OnSound?.Invoke("click"); onClick?.Invoke(); });
            b.SetState(BtnState.Normal);
            return b;
        }

        /// <summary>Width a button needs for its label.</summary>
        public static float PreferredWidth(Btn b, float pad = 30, float min = 90)
        {
            var v = b.label.GetPreferredValues(b.label.text, 4000, 100);
            return Mathf.Max(min, v.x + pad * 2);
        }

        public static LayoutElement Size(GameObject go, float w = -1, float h = -1, float flexW = -1)
        {
            var le = go.GetComponent<LayoutElement>() ?? go.AddComponent<LayoutElement>();
            le.preferredWidth = w; le.preferredHeight = h; le.minHeight = h; le.flexibleWidth = flexW;
            return le;
        }

        public static ScrollRect Scroll(Transform parent, string name, out RectTransform content, float sensitivity = 40)
        {
            var rt = Rect(name, parent);
            var sr = rt.gameObject.AddComponent<ScrollRect>();
            var vp = Rect("Viewport", rt); Stretch(vp);
            vp.gameObject.AddComponent<RectMask2D>();
            var hit = vp.gameObject.AddComponent<Image>(); hit.color = new Color(0, 0, 0, 0);
            content = Rect("Content", vp);
            content.anchorMin = new Vector2(0, 1); content.anchorMax = new Vector2(1, 1); content.pivot = new Vector2(0.5f, 1);
            content.anchoredPosition = Vector2.zero; content.sizeDelta = Vector2.zero;
            sr.viewport = vp; sr.content = content; sr.horizontal = false; sr.vertical = true;
            sr.movementType = ScrollRect.MovementType.Elastic; sr.elasticity = 0.08f; sr.inertia = true; sr.decelerationRate = 0.12f;
            sr.scrollSensitivity = sensitivity;
            // Thin cyan scrollbar
            var bar = Rect("Scrollbar", rt);
            bar.anchorMin = new Vector2(1, 0); bar.anchorMax = new Vector2(1, 1); bar.pivot = new Vector2(1, 0.5f);
            bar.sizeDelta = new Vector2(8, -12); bar.anchoredPosition = new Vector2(-3, 0);
            var barBg = bar.gameObject.AddComponent<Image>(); barBg.sprite = Art.Round; barBg.type = Image.Type.Sliced; barBg.color = Palette.Cyan.A(0.12f); barBg.pixelsPerUnitMultiplier = 8;
            var handleArea = Rect("Area", bar); Stretch(handleArea);
            var handle = Rect("Handle", handleArea); Stretch(handle);
            var hImg = handle.gameObject.AddComponent<Image>(); hImg.sprite = Art.Round; hImg.type = Image.Type.Sliced; hImg.color = Palette.Cyan.A(0.8f); hImg.pixelsPerUnitMultiplier = 8;
            var sb = bar.gameObject.AddComponent<Scrollbar>();
            sb.handleRect = handle; sb.targetGraphic = hImg; sb.direction = Scrollbar.Direction.BottomToTop;
            var nav = sb.navigation; nav.mode = Navigation.Mode.None; sb.navigation = nav;
            sr.verticalScrollbar = sb; sr.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport;
            sr.verticalScrollbarSpacing = 4;
            return sr;
        }

        public static VerticalLayoutGroup VStack(RectTransform rt, float spacing, RectOffset pad)
        {
            var v = rt.gameObject.AddComponent<VerticalLayoutGroup>();
            v.spacing = spacing; v.padding = pad; v.childControlHeight = true; v.childControlWidth = true;
            v.childForceExpandHeight = false; v.childForceExpandWidth = true;
            var f = rt.gameObject.AddComponent<ContentSizeFitter>(); f.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            return v;
        }

        public static TMP_InputField Input(Transform parent, string placeholder, float size)
        {
            var rt = Rect("Input", parent);
            var bg = rt.gameObject.AddComponent<Image>(); bg.sprite = Art.Round; bg.type = Image.Type.Sliced; bg.color = Palette.Paper; bg.pixelsPerUnitMultiplier = 2;
            Outline(rt, Palette.Edge, 16);
            var area = Rect("Text Area", rt); Stretch(area, 18, 8, 18, 8);
            area.gameObject.AddComponent<RectMask2D>();
            var ph = Text(area, placeholder, size, Palette.InkMuted.A(0.7f), TextAlignmentOptions.MidlineLeft); Stretch(ph.rectTransform);
            ph.fontStyle = FontStyles.Italic;
            var tx = Text(area, "", size, Palette.Ink, TextAlignmentOptions.MidlineLeft); Stretch(tx.rectTransform);
            var input = rt.gameObject.AddComponent<TMP_InputField>();
            input.textViewport = area; input.textComponent = tx; input.placeholder = ph; input.fontAsset = Font;
            input.pointSize = size; input.lineType = TMP_InputField.LineType.SingleLine; input.richText = false;
            input.caretColor = Palette.Ink; input.customCaretColor = true; input.selectionColor = Palette.Cyan.A(0.4f);
            var nav = input.navigation; nav.mode = Navigation.Mode.None; input.navigation = nav;
            return input;
        }
    }

    /// <summary>Left-to-right wrapping layout (chips, option buttons). Children size from their LayoutElement.</summary>
    public class FlowLayout : LayoutGroup
    {
        public float spacingX = 12, spacingY = 12;
        public bool centerRows;

        public override void CalculateLayoutInputHorizontal() { base.CalculateLayoutInputHorizontal(); SetLayoutInputForAxis(padding.horizontal, padding.horizontal, -1, 0); }
        public override void CalculateLayoutInputVertical() { float h = Run(rectTransform.rect.width, false); SetLayoutInputForAxis(h, h, -1, 1); }
        public override void SetLayoutHorizontal() { Run(rectTransform.rect.width, true); }
        public override void SetLayoutVertical() { Run(rectTransform.rect.width, true); }

        public float HeightFor(float width)
        {
            base.CalculateLayoutInputHorizontal();
            return Run(width, false);
        }

        float Run(float width, bool apply)
        {
            float maxW = Mathf.Max(10, width - padding.horizontal);
            float y = padding.top;
            var row = new List<(RectTransform rt, float w, float h)>();
            float rowW = 0, rowH = 0;
            void Flush()
            {
                if (row.Count == 0) return;
                float x = padding.left + (centerRows ? (maxW - rowW) / 2f : 0);
                if (apply)
                    foreach (var c in row)
                    {
                        SetChildAlongAxis(c.rt, 0, x, c.w);
                        SetChildAlongAxis(c.rt, 1, y + (rowH - c.h) / 2f, c.h);
                        x += c.w + spacingX;
                    }
                y += rowH + spacingY;
                row.Clear(); rowW = 0; rowH = 0;
            }
            foreach (var c in rectChildren)
            {
                float w = Mathf.Min(LayoutUtility.GetPreferredWidth(c), maxW);
                if (LayoutUtility.GetFlexibleWidth(c) > 0) w = maxW;
                float h = LayoutUtility.GetPreferredHeight(c);
                float need = row.Count == 0 ? w : rowW + spacingX + w;
                if (row.Count > 0 && need > maxW) { Flush(); need = w; }
                row.Add((c, w, h)); rowW = need; rowH = Mathf.Max(rowH, h);
            }
            Flush();
            return Mathf.Max(0, y - spacingY + padding.bottom);
        }
    }

    /// <summary>
    /// TMP writes &lt;mark&gt; highlight quads with an SDF scale of 0 (uv0.w), which the SDF shader renders
    /// fully transparent. This gives those quads the text's own scale so highlights are visible.
    /// </summary>
    public class MarkFix : MonoBehaviour
    {
        TMP_Text text;
        void OnEnable() { text = GetComponent<TMP_Text>(); if (text != null) text.OnPreRenderText += Fix; }
        void OnDisable() { if (text != null) text.OnPreRenderText -= Fix; }

        static void Fix(TMP_TextInfo info)
        {
            for (int m = 0; m < info.meshInfo.Length; m++)
            {
                var mi = info.meshInfo[m];
                if (mi.uvs0 == null || mi.vertexCount == 0) continue;
                float scale = 0;
                for (int v = 0; v < mi.vertexCount && scale == 0; v++) scale = Mathf.Abs(mi.uvs0[v].w);
                if (scale == 0) continue;
                for (int v = 0; v < mi.vertexCount; v++)
                    if (mi.uvs0[v].w == 0) mi.uvs0[v].w = scale;
            }
        }
    }

    /// <summary>Forwards clicks on TMP &lt;link&gt; tags (tappable markers inside passages).</summary>
    public class LinkClick : MonoBehaviour, IPointerClickHandler
    {
        public TextMeshProUGUI text;
        public Action<string> onLink;
        public void OnPointerClick(PointerEventData e)
        {
            if (text == null || onLink == null) return;
            int i = TMP_TextUtilities.FindIntersectingLink(text, e.position, null);
            if (i >= 0) onLink(text.textInfo.linkInfo[i].GetLinkID());
        }
    }
}
