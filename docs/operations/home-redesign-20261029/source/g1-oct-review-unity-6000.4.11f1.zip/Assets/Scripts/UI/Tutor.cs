using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace F2R
{
    /// <summary>Pre-written tutor lines. SUNI is a scripted tutor; nothing here calls a live AI service.</summary>
    public static class TutorLines
    {
        static readonly System.Random rng = new System.Random();
        static string Pick(params string[] s) => s[rng.Next(s.Length)];

        public static string Home(int total, int done) => done == 0
            ? $"안녕하세요, 수니예요! 10월 모의고사 지문으로 복습 문제를 준비했어요. 챕터와 유형을 고르고 '미션 시작'을 눌러 주세요. 지금 수록된 문항은 모두 {total}개예요."
            : $"다시 만나서 반가워요! 지금까지 {total}문항 중 {done}문항을 풀었어요. 오늘도 한 걸음씩 가 봐요.";

        public static string HomeTip() => Pick(
            "어법 문제는 '주어-동사 수 일치', '완전한 절/불완전한 절', '병렬 구조' 세 가지만 먼저 확인해도 절반은 해결돼요.",
            "문장 순서·문장 넣기는 however 같은 연결어와 that, this, they 같은 지시어가 가장 큰 단서예요.",
            "틀린 문제는 오답 노트에 자동으로 모여요. '오답만 다시 풀기'로 약한 유형을 집중 공략해 봐요.",
            "시간 제한이 부담되면 '무제한'으로 바꿔도 괜찮아요. 풀이 시간은 그래도 기록돼요.");

        public static string Start(Question q)
        {
            switch (q.kind)
            {
                case QKind.Choice: return q.box != null && q.target != null && q.box.Contains(q.target)
                    ? "요약문은 본문 내용을 다른 말로 바꾼 거예요. 본문에서 같은 의미의 표현을 찾아 비교해 봐요."
                    : "괄호 앞뒤를 보고 주어와 동사의 수, 뒤에 오는 절이 완전한지, 앞의 동사가 어떤 형태를 요구하는지 확인해 봐요.";
                case QKind.Order: return "주어진 글의 마지막 내용과 각 단락 첫 문장의 연결어·지시어를 이어 보세요. (A)(B)(C)를 순서대로 누르면 돼요.";
                case QKind.Insert: return "주어진 문장의 연결어와 대명사가 무엇을 가리키는지 찾고, 흐름이 끊기는 곳을 찾아봐요.";
                case QKind.PickNumber: return "글의 중심 흐름을 먼저 잡고, 그 흐름과 반대 방향을 가리키는 낱말을 찾아봐요.";
                case QKind.Judge: return "표시된 표현이 문장에서 맡은 역할(주어, 동사, 접속사, 목적격 보어)을 확인해 봐요.";
                case QKind.TrueFalse: return "진술문의 핵심 표현을 본문에서 찾아 한 단어씩 대조해 봐요. 'not only… but also', 'eliminate' 같은 말에 주의!";
                case QKind.Short: return "답은 본문 속에 그대로 있어요. 찾은 표현을 영어로 정확히 옮겨 적어 봐요.";
                default: return "핵심 내용을 먼저 머릿속(또는 노트)에 정리한 뒤 '모범답안 확인'을 눌러 스스로 비교해 봐요.";
            }
        }

        public static string GenericHint(Question q)
        {
            switch (q.kind)
            {
                case QKind.Order: return "각 단락의 첫 문장에 있는 연결어와 지시어가 앞 단락의 무엇과 이어지는지 확인해 보세요.";
                case QKind.Insert: return "주어진 문장 바로 뒤에 올 문장의 대명사·연결어를 확인해 보세요.";
                case QKind.TrueFalse: return "진술문의 핵심 단어를 본문에서 찾아 의미가 같은지 비교해 보세요.";
                default: return "지문의 표시된 부분 앞뒤 문장 구조를 천천히 다시 읽어 보세요.";
            }
        }

        public static string Correct(int streak) => streak >= 3
            ? Pick($"{streak}연속 정답! 근거를 잡고 푸는 게 보여요.", $"와, {streak}연속이에요! 이 흐름 그대로 가요.")
            : Pick("정답이에요! 해설로 근거까지 한 번 더 확인해 봐요.", "좋아요, 정확해요! 왜 맞는지 해설에서 확인해 볼까요?", "맞았어요! 같은 원리가 다른 문항에도 나와요.");

        public static string Wrong() => Pick(
            "괜찮아요, 틀린 문제가 제일 많이 남아요. 해설의 근거를 지문에서 직접 찾아봐요.",
            "아깝다! 정답 문장을 소리 내어 한 번 읽어 보면 오래 기억돼요. 오답 노트에 담아 둘게요.",
            "이 유형은 단서 하나만 잡으면 쉬워져요. 해설을 천천히 읽어 봐요.");

        public static string Timeout() => "시간이 다 됐어요. 미응답으로 기록하고 정답과 해설을 보여 드릴게요. 준비되면 '다음'을 눌러요.";
        public static string SelfCheck() => "모범답안과 내 답을 비교해 보세요. 핵심 내용이 들어갔다면 '맞게 썼어요'를 눌러요.";
        public static string Paused() => "잠깐 쉬어 가요. 타이머는 멈춰 있어요. 준비되면 '계속하기'를 눌러 주세요.";
        public static string Finish(float acc) => acc >= 0.8f ? "미션 완료! 정답률이 아주 좋아요. 유형별 강점을 확인해 봐요."
            : acc >= 0.5f ? "미션 완료! 절반 이상 맞혔어요. 오답만 다시 풀면 금방 올라갈 거예요."
            : "미션 완료! 오늘 틀린 문제가 내일의 점수예요. 오답 노트로 한 번 더 복습해 봐요.";
    }

    /// <summary>Always-visible tutor panel: portrait, name plate, speech bubble, hint button.</summary>
    public class TutorPanel
    {
        public RectTransform root;
        Image frame;
        RectTransform portraitRt, bubbleRt, nameRt, headerRt, footerRt;
        RawImage portrait;
        TextMeshProUGUI placeholderLabel, header, nameText, bubbleText, footer;
        ScrollRect bubbleScroll;
        public Btn hintBtn;
        public Action onHint;
        public bool HasPortrait { get; private set; }
        public Texture PortraitTexture => portrait.texture;
        public Rect PortraitUV => portrait.uvRect;
        /// <summary>The creator-supplied SUNI portrait is bundled locally for offline and browser use.</summary>
        public const string PortraitResource = "Media/suni_tutor";
        /// <summary>Optional "focusX focusY zoom" (UV space, y up) to frame her face inside the square frame.</summary>
        public const string PortraitCropResource = "Media/suni_tutor_crop";
        float typeT; int typeTarget;

        public TutorPanel(Transform parent)
        {
            frame = UI.Card(parent, "TutorPanel", Palette.Panel, Palette.EdgeSoft, 20);
            root = frame.rectTransform;
            header = UI.Text(root, "YOUR TUTOR · SUNI · 수니", 17, Palette.CyanSoft, TextAlignmentOptions.MidlineLeft, true, "Header");
            header.characterSpacing = 4;
            headerRt = header.rectTransform;

            var pf = UI.Card(root, "PortraitFrame", Palette.Hex("#0A3D8F"), Palette.Edge, 18);
            portraitRt = pf.rectTransform;
            UI.Glow(portraitRt, Palette.Cyan.A(0.35f), 16).transform.SetAsFirstSibling();
            var mask = UI.Rect("Mask", portraitRt); UI.Stretch(mask, 4, 4, 4, 4);
            mask.gameObject.AddComponent<RectMask2D>();
            portrait = UI.Rect("Portrait", mask).gameObject.AddComponent<RawImage>();
            UI.Stretch(portrait.rectTransform);
            portrait.raycastTarget = false;
            var tex = Resources.Load<Texture2D>(PortraitResource);
            HasPortrait = tex != null;
            portrait.texture = tex != null ? tex : Art.PortraitPlaceholder();
            placeholderLabel = UI.Text(mask, "<size=150%><b>SUNI · 수니</b></size>\n<size=60%><color=#8BEAFF>사진을 불러올 수 없어요</color></size>", 30, Palette.White, TextAlignmentOptions.Center, false, "Placeholder");
            UI.Stretch(placeholderLabel.rectTransform);
            placeholderLabel.gameObject.SetActive(!HasPortrait);
            if (HasPortrait) FitPortrait();
            else Debug.LogWarning("[F2R media] Bundled SUNI portrait could not be loaded from Resources/Media/suni_tutor.");

            nameText = UI.Text(root, "<b>SUNI · 수니</b>  <size=75%><color=#9FB4DA>F2R 학습 튜터</color></size>", 22, Palette.White, TextAlignmentOptions.MidlineLeft, false, "Name");
            nameRt = nameText.rectTransform;

            var bubble = UI.Card(root, "Bubble", Palette.Hex("#0B2459F0"), Palette.Edge.A(0.8f), 16);
            bubbleRt = bubble.rectTransform;
            bubbleScroll = UI.Scroll(bubbleRt, "BubbleScroll", out var content, 30);
            UI.Stretch((RectTransform)bubbleScroll.transform, 4, 6, 4, 6);
            UI.VStack(content, 0, new RectOffset(14, 18, 8, 10));
            bubbleText = UI.Text(content, "", 20, Palette.White, TextAlignmentOptions.TopLeft, false, "BubbleText");
            bubbleText.lineSpacing = 8;

            hintBtn = UI.Button(root, "SUNI · 수니 힌트 (H)", 21, BtnStyle.Soft, () => onHint?.Invoke(), "HintButton");
            footer = UI.Text(root, "미리 준비된 해설로 안내하는 스크립트 튜터예요", 14, Palette.TextMuted, TextAlignmentOptions.Center, false, "Footer");
            footerRt = footer.rectTransform;
        }

        /// <summary>Crops the existing picture to the square frame (no redraw): cover-fit around a focus point.</summary>
        void FitPortrait()
        {
            var t = portrait.texture;
            float fx = 0.5f, fy = 0.62f, zoom = 1f;
            var cfg = Resources.Load<TextAsset>(PortraitCropResource);
            if (cfg != null)
            {
                var parts = cfg.text.Split(new[] { ' ', '\t', '\n', '\r', ',' }, StringSplitOptions.RemoveEmptyEntries);
                var inv = System.Globalization.CultureInfo.InvariantCulture;
                if (parts.Length >= 2 && float.TryParse(parts[0], System.Globalization.NumberStyles.Float, inv, out var x)
                    && float.TryParse(parts[1], System.Globalization.NumberStyles.Float, inv, out var y)) { fx = x; fy = y; }
                if (parts.Length >= 3 && float.TryParse(parts[2], System.Globalization.NumberStyles.Float, inv, out var z)) zoom = Mathf.Max(1f, z);
            }
            float aspect = t.width / (float)t.height;
            float uw = (aspect >= 1 ? 1f / aspect : 1f) / zoom, vh = (aspect >= 1 ? 1f : aspect) / zoom;
            float ux = Mathf.Clamp(fx - uw / 2, 0, 1 - uw), vy = Mathf.Clamp(fy - vh / 2, 0, 1 - vh);
            portrait.uvRect = new Rect(ux, vy, uw, vh);
        }

        public void Say(string text)
        {
            bubbleText.text = text;
            bubbleText.ForceMeshUpdate();
            typeTarget = bubbleText.textInfo.characterCount;
            bubbleText.maxVisibleCharacters = 0;
            typeT = 0;
            bubbleScroll.verticalNormalizedPosition = 1;
        }

        public void SetHint(bool visible, string label = "SUNI · 수니 힌트 (H)")
        {
            hintBtn.go.SetActive(visible);
            hintBtn.SetLabel(label);
        }

        public void Tick(float dt)
        {
            if (bubbleText.maxVisibleCharacters < typeTarget)
            {
                typeT += dt * 70f;
                bubbleText.maxVisibleCharacters = Mathf.Min(typeTarget, Mathf.FloorToInt(typeT));
            }
        }

        public void Layout(float w, float h, bool strip)
        {
            float pad = 16;
            placeholderLabel.fontSize = strip ? 18 : 30;
            if (!strip)
            {
                UI.Place(headerRt, pad + 4, 10, w - 2 * pad, 30);
                float ps = Mathf.Min(w - 2 * pad, h * 0.4f);
                UI.Place(portraitRt, (w - ps) / 2, 46, ps, ps);
                float y = 46 + ps + 10;
                UI.Place(nameRt, pad + 4, y, w - 2 * pad, 32);
                y += 40;
                float footerH = 22, hintH = 58;
                float bh = h - y - hintH - footerH - pad - 14;
                UI.Place(bubbleRt, pad, y, w - 2 * pad, Mathf.Max(60, bh));
                UI.Place(hintBtn.rt, pad, h - pad - footerH - hintH - 4, w - 2 * pad, hintH);
                UI.Place(footerRt, pad, h - pad - footerH + 2, w - 2 * pad, footerH);
                headerRt.gameObject.SetActive(true); footerRt.gameObject.SetActive(true); nameRt.gameObject.SetActive(true);
                bubbleText.fontSize = 20;
            }
            else
            {
                float ps = h - 2 * 12;
                UI.Place(portraitRt, 12, 12, ps, ps);
                float x = 12 + ps + 14;
                UI.Place(nameRt, x, 8, w - x - 190, 32);
                float hintW = 170;
                UI.Place(hintBtn.rt, w - hintW - 12, 8, hintW, 46);
                UI.Place(bubbleRt, x, 60, w - x - 12, h - 60 - 10);
                headerRt.gameObject.SetActive(false); footerRt.gameObject.SetActive(false);
                bubbleText.fontSize = 21;
            }
        }
    }
}
