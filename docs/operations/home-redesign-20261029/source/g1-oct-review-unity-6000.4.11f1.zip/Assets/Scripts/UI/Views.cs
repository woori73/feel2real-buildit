using System.Collections.Generic;
using System.Linq;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace F2R
{
    /// <summary>Scrollable document-style screen built from vertical stacks and flow rows.</summary>
    public abstract class DocView : View
    {
        protected ScrollRect scroll;
        protected RectTransform content;
        protected bool narrow;
        protected bool built;

        protected DocView(F2RApp app, string name) : base(app, name)
        {
            scroll = UI.Scroll(root, "Scroll", out content, 50);
            UI.Stretch((RectTransform)scroll.transform);
            UI.VStack(content, 18, new RectOffset(4, 20, 4, 30));
        }

        protected void Clear() { foreach (Transform c in content) Object.Destroy(c.gameObject); content.DetachChildren(); }

        protected TextMeshProUGUI Heading(Transform parent, string s, float size = 24)
        {
            var t = UI.Text(parent, s, size, Palette.CyanSoft, TextAlignmentOptions.TopLeft, true, "Heading");
            return t;
        }

        protected TextMeshProUGUI Para(Transform parent, string s, float size = 20, Color? c = null)
        {
            var t = UI.Text(parent, s, size, c ?? Palette.White, TextAlignmentOptions.TopLeft, false, "Para");
            t.lineSpacing = 8;
            return t;
        }

        protected RectTransform Box(Transform parent, string name, Color? fill = null)
        {
            var img = UI.Card(parent, name, fill ?? Palette.Panel, Palette.EdgeSoft, 18);
            var v = img.gameObject.AddComponent<VerticalLayoutGroup>();
            v.padding = new RectOffset(22, 22, 18, 20); v.spacing = 12;
            v.childControlHeight = true; v.childControlWidth = true; v.childForceExpandHeight = false; v.childForceExpandWidth = true;
            return img.rectTransform;
        }

        protected RectTransform Flow(Transform parent, float sx = 12, float sy = 12)
        {
            var rt = UI.Rect("Flow", parent);
            var f = rt.gameObject.AddComponent<FlowLayout>(); f.spacingX = sx; f.spacingY = sy;
            return rt;
        }

        protected Btn Chip(Transform parent, string label, bool on, System.Action act, float size = 20, float h = 52)
        {
            var b = UI.Button(parent, label, size, BtnStyle.Ghost, act, "Chip");
            UI.Size(b.go, UI.PreferredWidth(b, 22, 80), h);
            b.SetState(on ? BtnState.Selected : BtnState.Normal);
            return b;
        }

        protected Btn Action(Transform parent, string label, BtnStyle style, System.Action act, float h = 64, float size = 23)
        {
            var b = UI.Button(parent, label, size, style, act, "Action");
            UI.Size(b.go, UI.PreferredWidth(b, 30, 160), h);
            return b;
        }

        public override void Layout(float w, float h, bool portrait)
        {
            bool n = w < 820;
            if (n != narrow) { narrow = n; Rebuild(); }
        }

        protected abstract void Rebuild();

        public override void OnKey(Key k)
        {
            if (k == Key.UpArrow || k == Key.PageUp) scroll.verticalNormalizedPosition = Mathf.Clamp01(scroll.verticalNormalizedPosition + (k == Key.PageUp ? 0.3f : 0.08f));
            if (k == Key.DownArrow || k == Key.PageDown) scroll.verticalNormalizedPosition = Mathf.Clamp01(scroll.verticalNormalizedPosition - (k == Key.PageDown ? 0.3f : 0.08f));
        }

        public static string ResultName(Result r)
        {
            switch (r)
            {
                case Result.Correct: return "<color=#22D3EE>정답</color>";
                case Result.SelfCorrect: return "<color=#2BD99B>자기평가 정답</color>";
                case Result.Wrong: return "<color=#FF6B88>오답</color>";
                case Result.SelfWrong: return "<color=#FF6B88>자기평가 오답</color>";
                case Result.Unanswered: return "<color=#FFC24B>미응답</color>";
                default: return "<color=#7A88A8>미풀이</color>";
            }
        }

        public static string Fmt(float s) { int t = Mathf.FloorToInt(s); return $"{t / 60:00}:{t % 60:00}"; }

        /// <summary>Full explanation of a question for the notebook / results detail dialog.</summary>
        protected void ShowDetail(Question q, SessionItem item = null)
        {
            var sb = new StringBuilder();
            var ch = app.bank.GetChapter(q.chapter);
            sb.Append($"<color=#9FB4DA>{q.sourceId}. {q.sectionTitle} · {SectionInfo.Name(q.section)}{(ch != null && ch.title.Length > 0 ? " · " + ch.title : "")}</color>\n");
            sb.Append($"<b>{PassageRenderer.Esc(q.prompt)}</b>\n");
            if (q.box != null) sb.Append($"<color=#8BEAFF>{PassageRenderer.Esc(q.boxLabel)}</color>  {PassageRenderer.Esc(PassageRenderer.PlainBox(q))}\n");
            if (item != null) sb.Append($"\n<color=#9FB4DA>내 답</color>  {PassageRenderer.Esc(item.answer)}   ({ResultName((Result)item.result)}, {Fmt(item.time)})");
            sb.Append($"\n<color=#9FB4DA>정답</color>  <b><color=#2BD99B>{PassageRenderer.Esc(q.modelAnswer ?? q.answerDisplay)}</color></b>\n");
            if (!string.IsNullOrEmpty(q.explanation)) sb.Append("\n<b><color=#8BEAFF>■ SUNI · 수니 해설</color></b>\n").Append(PassageRenderer.Esc(q.explanation)).Append("\n");
            var s = PassageRenderer.CorrectSentence(q);
            if (!string.IsNullOrEmpty(s)) sb.Append("\n<b><color=#8BEAFF>■ 정답 문장</color></b>\n").Append(s).Append("\n");
            if (!string.IsNullOrEmpty(q.sourceNotice)) sb.Append("\n<color=#FFC24B>원본 확인 안내</color>\n").Append(PassageRenderer.Esc(q.sourceNotice)).Append("\n");
            if (q.vocab.Count > 0) sb.Append("\n<b><color=#8BEAFF>■ 핵심 어휘</color></b>\n").Append(string.Join("\n", q.vocab.Select(v => "· " + PassageRenderer.Esc(v))));
            app.modal.Show(q.id, sb.ToString(), null, ("닫기", BtnStyle.Primary, null));
        }
    }

    public class HomeView : DocView
    {
        public HomeView(F2RApp app) : base(app, "HomeView")
        {
            int done = app.save.records.Count(r => app.bank.byId.ContainsKey(r.id));
            app.tutor.Say(TutorLines.Home(app.bank.Count, done));
            app.tutor.SetHint(true, "SUNI · 수니 학습 팁");
            Rebuild();
        }

        List<int> SelChapters => app.save.selChapters;
        List<int> SelSections => app.save.selSections;

        List<Section> SectionsPresent(IEnumerable<Question> qs) => SectionInfo.Order.Where(s => qs.Any(q => q.section == s)).ToList();

        protected override void Rebuild()
        {
            float keep = scroll.verticalNormalizedPosition;
            Clear();
            var all = app.bank.chapters.SelectMany(c => c.questions).ToList();
            var recs = app.save.records.Where(r => app.bank.byId.ContainsKey(r.id)).ToList();
            int tried = recs.Count;
            int firstOk = recs.Count(r => r.firstResult == (int)Result.Correct || r.firstResult == (int)Result.SelfCorrect);

            // Hero
            var hero = Box(content, "Hero", Palette.Hex("#0F3277E6"));
            UI.Glow(hero, Palette.Cyan.A(0.18f), 14).transform.SetAsFirstSibling();
            UI.Text(hero, "고1 10월 영어 복습", narrow ? 34 : 40, Palette.White, TextAlignmentOptions.TopLeft, true, "Title");
            Para(hero, "문항과 유형을 고르고 시작하세요.", 22, Palette.White);
            Para(hero, $"수록 문항 <b>{all.Count}개</b> · 풀어 본 문항 <b>{tried}</b>개 · 최초 정답률 <b>{(tried == 0 ? "-" : Mathf.RoundToInt(100f * firstOk / tried) + "%")}</b> · 누적 <color=#FFC24B><b>{app.save.totalXP} XP</b></color>", 20, Palette.TextMuted);
            var heroBtns = Flow(hero);
            var sess = app.Session;
            if (sess.active && sess.items.Count > 0)
                Action(heroBtns, $"이어하기 ({sess.items.Count(i => i.done)}/{sess.items.Count}) ▶", BtnStyle.Primary, app.ResumeSession);
            Action(heroBtns, $"오답 노트 ({app.save.notebook.Count(id => app.bank.byId.ContainsKey(id))})", BtnStyle.Soft, app.ShowNotebook);
            if (app.save.lastResult != null && app.save.lastResult.items.Count > 0) Action(heroBtns, "최근 결과 보기", BtnStyle.Ghost, app.ShowResults);

            // Step 1: chapters
            var s1 = Box(content, "Chapters");
            Heading(s1, "STEP 1 · 챕터 선택 <size=75%><color=#9FB4DA>(원본 시험 문항 번호, 제공된 자료만 수록)</color></size>");
            var cf = Flow(s1, 14, 14);
            foreach (var ch in app.bank.chapters)
            {
                int n = ch.questions.Count;
                int t = ch.questions.Count(q => app.save.Rec(q.id, false) != null);
                int ok = ch.questions.Count(q => { var r = app.LastResult(q.id); return r == Result.Correct || r == Result.SelfCorrect; });
                bool on = SelChapters.Count == 0 || SelChapters.Contains(ch.number);
                int num = ch.number;
                var b = UI.Button(cf, $"<size=145%><b>{ch.number}번</b></size>\n<size=80%>{PassageRenderer.Esc(ch.title)}</size>\n<size=72%>{t}/{n} 풀이 · 현재 정답 {ok}</size>", 22, BtnStyle.Ghost, () => ToggleChapter(num), "ChapterCard");
                b.label.alignment = TextAlignmentOptions.MidlineLeft; b.label.lineSpacing = 4;
                UI.Size(b.go, narrow ? 360 : 330, 136);
                b.SetState(on ? BtnState.Selected : BtnState.Normal);
            }
            if (app.bank.chapters.Count > 1) Chip(cf, "전체 선택", SelChapters.Count == 0, () => { SelChapters.Clear(); Changed(); });
            Para(s1, "117개 원본 그룹 · 18개 지문 (20–24, 29–41번). 41번은 41–42 통합 지문이에요. 25–28번과 별도 42번은 제공되지 않았어요.", 17, Palette.TextMuted);

            // Step 2: types
            var chosenCh = app.bank.chapters.Where(c => SelChapters.Count == 0 || SelChapters.Contains(c.number)).SelectMany(c => c.questions).ToList();
            var s2 = Box(content, "Types");
            Heading(s2, "STEP 2 · 유형 선택");
            var tf = Flow(s2);
            Chip(tf, $"전체 유형  {chosenCh.Count}", SelSections.Count == 0, () => { SelSections.Clear(); Changed(); });
            foreach (var sec in SectionsPresent(chosenCh))
            {
                var s = sec;
                Chip(tf, $"{SectionInfo.Name(sec)}  {chosenCh.Count(q => q.section == sec)}", SelSections.Count > 0 && SelSections.Contains((int)sec), () => ToggleSection(s));
            }

            // Step 3 + 4
            var pool = app.Pool(SelChapters, SelSections.Select(x => (Section)x));
            var s3 = Box(content, "Options");
            Heading(s3, "STEP 3 · 문항 수");
            var nf = Flow(s3);
            string[] counts = { "5문항", "10문항", $"전체 ({pool.Count}문항)" };
            for (int i = 0; i < 3; i++) { int ci = i; Chip(nf, counts[i], app.save.countMode == i, () => { app.save.countMode = ci; Changed(); }); }
            Heading(s3, "STEP 4 · 문제당 제한 시간");
            var tmf = Flow(s3);
            foreach (var sec in F2RApp.TimerOptions)
            {
                int v = sec;
                Chip(tmf, v == 0 ? "무제한" : $"{v}초", app.save.timerSec == v, () => { app.save.timerSec = v; Changed(); });
            }
            int count = app.save.countMode == 0 ? 5 : app.save.countMode == 1 ? 10 : pool.Count;
            count = Mathf.Min(count, pool.Count);
            var startRow = Flow(s3, 18, 10);
            var start = Action(startRow, "미션 시작 ▶", BtnStyle.Primary, () => StartMission(pool), 74, 28);
            start.Interactable = pool.Count > 0;
            var info = Para(startRow, $"<color=#9FB4DA>{count}문항 · {(app.save.timerSec == 0 ? "시간 제한 없음" : $"문제당 {app.save.timerSec}초")}\n안 푼 문항 → 틀린 문항 순으로 골라 원래 순서대로 출제해요.</color>", 18);
            UI.Size(info.gameObject, narrow ? 500 : 520, 74);
            info.alignment = TextAlignmentOptions.MidlineLeft;

            // Progress map
            var map = Box(content, "Map");
            Heading(map, "미션 맵 · 진행 현황");
            foreach (var ch in app.bank.chapters)
            {
                Para(map, $"<b>{ch.number}번</b>  <color=#9FB4DA>{PassageRenderer.Esc(ch.title)}</color>", 19);
                var df = Flow(map, 6, 8);
                string prevSrc = null;
                foreach (var q in ch.questions)
                {
                    if (prevSrc != null && prevSrc != q.sourceId) { var gap = UI.Rect("Gap", df); UI.Size(gap.gameObject, 10, 22); }
                    prevSrc = q.sourceId;
                    var d = UI.Rect("Dot", df);
                    var img = d.gameObject.AddComponent<Image>(); img.sprite = Art.Disc; img.raycastTarget = false;
                    img.color = Palette.ForResult(app.LastResult(q.id));
                    UI.Size(d.gameObject, 22, 22);
                }
                var groups = ch.questions.GroupBy(q => q.sourceId).Select(g => $"{g.Key}({g.Count()})");
                Para(map, "<size=85%><color=#7A88A8>" + string.Join("  ", groups) + "</color></size>", 16);
            }
            Para(map, "<color=#22D3EE>●</color> 정답   <color=#2BD99B>●</color> 자기평가 정답   <color=#FF6B88>●</color> 오답   <color=#FFC24B>●</color> 미응답   <color=#3A4E7A>●</color> 미풀이", 18);

            // Settings
            var set = Box(content, "Settings");
            Heading(set, "설정");
            var ff = Flow(set);
            Para(ff, "지문 글자 크기", 19, Palette.TextMuted).gameObject.AddComponent<LayoutElement>().preferredWidth = 150;
            string[] fs = { "작게", "보통", "크게", "아주 크게" };
            for (int i = 0; i < fs.Length; i++) { int fi = i; Chip(ff, fs[i], app.save.fontStep == i, () => { app.save.fontStep = fi; Changed(); }, 19, 48); }
            var of = Flow(set);
            Chip(of, app.save.sfx ? "효과음 켜짐" : "효과음 꺼짐", app.save.sfx, () => { app.save.sfx = !app.save.sfx; app.sfx.enabled = app.save.sfx; app.top.Refresh(); Changed(); }, 19, 48);
            Chip(of, app.save.clips ? "인트로·보상 연출 켜짐" : "인트로·보상 연출 꺼짐", app.save.clips, () => { app.save.clips = !app.save.clips; Changed(); }, 19, 48);
            Para(set, Storage.Available
                ? "<color=#2BD99B>●</color> 학습 기록은 이 브라우저에 자동 저장돼요. 계정이나 개인정보는 필요 없어요."
                : "<color=#FFC24B>●</color> 이 환경에서는 브라우저 저장소를 쓸 수 없어요. 이번 접속 동안만 기록이 유지돼요. 아래 내보내기/가져오기로 복구 텍스트를 보관해 주세요.", 18, Palette.TextMuted);
            var rf = Flow(set);
            Action(rf, "기록 내보내기 / 가져오기", BtnStyle.Soft, () => app.SetView(new RecoveryView(app)), 54, 20);
            Action(rf, "학습 기록 초기화", BtnStyle.Danger, ConfirmReset, 54, 20);

            Para(content, "<size=85%><color=#7A88A8>글꼴: IBM Plex Sans KR (SIL OFL) · 로고: F2R 원본 SVG · SUNI · 수니는 미리 작성된 해설로 안내하는 스크립트 튜터이며 실시간 AI 서비스가 아니에요. 지문·정답은 제공된 복습 워크시트 원문을 그대로 사용했어요.</color></size>", 16);

            Canvas.ForceUpdateCanvases();
            scroll.verticalNormalizedPosition = built ? keep : 1;
            built = true;
        }

        void Changed() { app.Persist(); Rebuild(); }

        void ToggleChapter(int n)
        {
            if (SelChapters.Count == 0) { SelChapters.Clear(); SelChapters.Add(n); }
            else if (SelChapters.Contains(n)) { SelChapters.Remove(n); }
            else SelChapters.Add(n);
            if (SelChapters.Count == app.bank.chapters.Count) SelChapters.Clear();
            SelSections.Clear();
            Changed();
        }

        void ToggleSection(Section s)
        {
            int v = (int)s;
            if (SelSections.Contains(v)) SelSections.Remove(v); else SelSections.Add(v);
            Changed();
        }

        void StartMission(List<Question> pool)
        {
            if (pool.Count == 0) return;
            int n = app.save.countMode == 0 ? 5 : app.save.countMode == 1 ? 10 : 0;
            var pick = app.PickForSession(pool, n);
            if (app.Session.active && app.Session.items.Any(i => !i.done))
                app.modal.Show("새 미션을 시작할까요?", "진행 중인 미션이 있어요. 새로 시작하면 진행 중이던 미션은 종료돼요. (이미 푼 문항의 기록은 그대로 남아요.)", null,
                    ("취소", BtnStyle.Ghost, null), ("새로 시작", BtnStyle.Primary, () => app.StartSession(pick, "일반")));
            else app.StartSession(pick, "일반");
        }

        void ConfirmReset()
        {
            app.modal.Show("학습 기록을 초기화할까요?", "풀이 기록, 오답 노트, 진행 중인 미션, 누적 XP가 모두 지워져요. 이 작업은 되돌릴 수 없어요.\n(글자 크기·효과음 설정은 유지돼요.)", null,
                ("취소", BtnStyle.Ghost, null), ("초기화", BtnStyle.Danger, app.ResetAll));
        }

        public override void OnKey(Key k)
        {
            base.OnKey(k);
            if (k == Key.Enter || k == Key.NumpadEnter)
            {
                if (app.Session.active && app.Session.items.Any(i => !i.done)) app.ResumeSession();
                else StartMission(app.Pool(SelChapters, SelSections.Select(x => (Section)x)));
            }
        }
    }

    public class ResultsView : DocView
    {
        SessionState S => app.save.lastResult;

        public ResultsView(F2RApp app) : base(app, "ResultsView")
        {
            app.tutor.SetHint(true, "SUNI · 수니 학습 팁");
            int n = S.items.Count;
            int ok = S.items.Count(i => Good(i));
            app.tutor.Say(n == 0 ? "아직 완료한 미션이 없어요." : TutorLines.Finish(ok / (float)n));
            Rebuild();
        }

        static bool Good(SessionItem i) => i.result == (int)Result.Correct || i.result == (int)Result.SelfCorrect;

        protected override void Rebuild()
        {
            Clear();
            var items = S.items.Where(i => i.done && app.bank.byId.ContainsKey(i.id)).ToList();
            int n = items.Count;
            int ok = items.Count(Good);
            int auto = items.Count(i => i.result == (int)Result.Correct);
            int un = items.Count(i => i.result == (int)Result.Unanswered);
            float total = items.Sum(i => i.time);

            var head = Box(content, "Head", Palette.Hex("#0F3277E6"));
            UI.Text(head, $"미션 결과 <size=60%><color=#9FB4DA>· {S.mode}</color></size>", 38, Palette.White, TextAlignmentOptions.TopLeft, true);
            var stats = Flow(head, 14, 14);
            void Stat(string label, string value, Color c)
            {
                var p = UI.Card(stats, "Stat", Palette.Hex("#0A2253F2"), Palette.EdgeSoft, 14);
                var t = UI.Text(p.rectTransform, $"<size=70%><color=#9FB4DA>{label}</color></size>\n<b>{value}</b>", 32, c, TextAlignmentOptions.Center);
                UI.Stretch(t.rectTransform, 8, 8, 8, 8);
                UI.Size(p.gameObject, narrow ? 196 : 212, 104);
            }
            Stat("최초 시도 정답률", n == 0 ? "-" : $"{Mathf.RoundToInt(100f * ok / n)}%", Palette.Cyan);
            Stat("정답 / 전체", $"{ok} / {n}", Palette.White);
            Stat("획득 XP", $"+{S.score}", Palette.Amber);
            Stat("총 풀이 시간", Fmt(total), Palette.White);
            Stat("평균 시간", n == 0 ? "-" : Fmt(total / n), Palette.White);
            Stat("미응답", $"{un}", un > 0 ? Palette.Amber : Palette.White);
            Stat("최고 연속 정답", $"{S.bestStreak}", Palette.Green);
            Para(head, $"<color=#9FB4DA>자동 채점 정답 {auto} · 자기평가 정답 {ok - auto}. 자기평가 문항은 +50 XP, 연속 보너스는 4초 이상 읽고 맞힌 경우에만 붙어요.</color>", 17);

            var btns = Flow(head);
            var wrong = items.Where(i => !Good(i)).Select(i => app.bank.byId[i.id]).ToList();
            var retry = Action(btns, $"오답만 다시 풀기 ({wrong.Count})", BtnStyle.Primary, () => app.StartSession(wrong, "오답만 다시"));
            retry.Interactable = wrong.Count > 0;
            if (wrong.Count == 0) retry.SetState(BtnState.Dim);
            Action(btns, "전체 다시 풀기", BtnStyle.Soft, () => app.StartSession(items.Select(i => app.bank.byId[i.id]).ToList(), "전체 다시"));
            Action(btns, "오답 노트", BtnStyle.Ghost, app.ShowNotebook);
            Action(btns, "홈으로", BtnStyle.Ghost, app.ShowHome);

            // Strengths by type
            var st = Box(content, "Strengths");
            Heading(st, "유형별 강점");
            foreach (var g in items.GroupBy(i => app.bank.byId[i.id].section).OrderBy(g => (int)g.Key))
            {
                int gn = g.Count(), gok = g.Count(Good);
                float r = gok / (float)gn;
                var row = UI.Rect("Row", st); UI.Size(row.gameObject, -1, 40);
                var name = UI.Text(row, SectionInfo.Name(g.Key), 20, Palette.White, TextAlignmentOptions.MidlineLeft);
                name.rectTransform.anchorMin = new Vector2(0, 0); name.rectTransform.anchorMax = new Vector2(0.3f, 1); name.rectTransform.offsetMin = name.rectTransform.offsetMax = Vector2.zero;
                var bg = UI.Panel(row, Palette.Cyan.A(0.12f), 8, "BarBg");
                bg.rectTransform.anchorMin = new Vector2(0.3f, 0.3f); bg.rectTransform.anchorMax = new Vector2(0.72f, 0.7f); bg.rectTransform.offsetMin = bg.rectTransform.offsetMax = Vector2.zero;
                var fill = UI.Panel(bg.rectTransform, r >= 0.8f ? Palette.Green : r >= 0.5f ? Palette.Cyan : Palette.Coral, 8, "Fill");
                fill.rectTransform.anchorMin = Vector2.zero; fill.rectTransform.anchorMax = new Vector2(Mathf.Max(0.02f, r), 1); fill.rectTransform.offsetMin = fill.rectTransform.offsetMax = Vector2.zero;
                string tag = r >= 0.8f ? "<color=#2BD99B>강점</color>" : r >= 0.5f ? "<color=#22D3EE>보통</color>" : "<color=#FF6B88>보완 필요</color>";
                var val = UI.Text(row, $"{Mathf.RoundToInt(r * 100)}% ({gok}/{gn})  {tag}", 19, Palette.White, TextAlignmentOptions.MidlineRight);
                val.rectTransform.anchorMin = new Vector2(0.72f, 0); val.rectTransform.anchorMax = new Vector2(1, 1); val.rectTransform.offsetMin = val.rectTransform.offsetMax = Vector2.zero;
            }

            // Per item
            var list = Box(content, "Items");
            Heading(list, "문항별 기록 <size=75%><color=#9FB4DA>(누르면 해설 보기)</color></size>");
            foreach (var it in items)
            {
                var q = app.bank.byId[it.id];
                var item = it;
                string text = narrow
                    ? $"<b>{q.id}</b>  <color=#9FB4DA>{SectionInfo.Name(q.section)}</color>  {ResultName((Result)it.result)}  <color=#9FB4DA>{Fmt(it.time)}{(it.hintUsed ? " · 힌트" : "")}</color>\n<size=88%>내 답 {PassageRenderer.Esc(Short(it.answer))}  →  정답 <color=#2BD99B>{PassageRenderer.Esc(Short(q.modelAnswer ?? q.answerDisplay))}</color></size>"
                    : $"<b>{q.id}</b><pos=13%><color=#9FB4DA>{SectionInfo.Name(q.section)}</color><pos=29%>내 답 {PassageRenderer.Esc(Short(it.answer))}<pos=55%>정답 <color=#2BD99B>{PassageRenderer.Esc(Short(q.modelAnswer ?? q.answerDisplay))}</color><pos=80%>{Fmt(it.time)}{(it.hintUsed ? " 힌트" : "")}<pos=89%>{ResultName((Result)it.result)}";
                var b = UI.Button(list, text, 19, BtnStyle.Ghost, () => ShowDetail(q, item), "ItemRow");
                b.label.alignment = TextAlignmentOptions.MidlineLeft;
                b.label.textWrappingMode = narrow ? TextWrappingModes.Normal : TextWrappingModes.NoWrap;
                b.label.overflowMode = TextOverflowModes.Ellipsis;
                UI.Size(b.go, -1, narrow ? 78 : 54);
            }
        }

        static string Short(string s) { if (string.IsNullOrEmpty(s)) return "-"; return s.Length > 26 ? s.Substring(0, 25) + "…" : s; }
    }

    public class NotebookView : DocView
    {
        public NotebookView(F2RApp app) : base(app, "NotebookView")
        {
            app.tutor.SetHint(true, "SUNI · 수니 학습 팁");
            app.tutor.Say(app.save.notebook.Count == 0 ? "오답 노트가 비어 있어요. 멋져요!" : "틀렸거나 시간이 지난 문항이 모여 있어요. 다시 맞히면 노트에서 자동으로 빠져요.");
            Rebuild();
        }

        protected override void Rebuild()
        {
            Clear();
            var qs = app.save.notebook.Where(id => app.bank.byId.ContainsKey(id)).Select(id => app.bank.byId[id]).OrderBy(q => q.order).ToList();
            var head = Box(content, "Head", Palette.Hex("#0F3277E6"));
            UI.Text(head, $"오답 노트 <size=60%><color=#9FB4DA>· {qs.Count}문항</color></size>", 38, Palette.White, TextAlignmentOptions.TopLeft, true);
            Para(head, "<color=#9FB4DA>틀린 문항, 미응답 문항, 자기평가에서 '못 썼어요'를 고른 문항이 저장돼요. 다시 풀어 맞히면 자동으로 빠져요.</color>", 18);
            var btns = Flow(head);
            var play = Action(btns, $"오답 노트 문제 풀기 ({qs.Count})", BtnStyle.Primary, () => app.StartSession(qs, "오답 노트"));
            play.Interactable = qs.Count > 0;
            if (qs.Count == 0) play.SetState(BtnState.Dim);
            Action(btns, "홈으로", BtnStyle.Ghost, app.ShowHome);

            var list = Box(content, "List");
            if (qs.Count == 0) Para(list, "아직 담긴 문항이 없어요.", 20, Palette.TextMuted);
            foreach (var q in qs)
            {
                var r = app.LastResult(q.id);
                var qq = q;
                string line = q.kind == QKind.TrueFalse ? PassageRenderer.PlainBox(q) : q.prompt;
                if (line.Length > 70) line = line.Substring(0, 68) + "…";
                var b = UI.Button(list, $"<b>{q.id}</b>  <color=#9FB4DA>{SectionInfo.Name(q.section)}</color>  {ResultName(r)}\n<size=85%>{PassageRenderer.Esc(line)}</size>", 19, BtnStyle.Ghost, () => ShowDetail(qq), "NoteRow");
                b.label.alignment = TextAlignmentOptions.MidlineLeft;
                UI.Size(b.go, -1, 84);
            }
        }
    }
}
