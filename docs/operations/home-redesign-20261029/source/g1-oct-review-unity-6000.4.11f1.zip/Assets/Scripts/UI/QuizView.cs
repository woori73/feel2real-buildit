using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace F2R
{
    public class QuizView : View
    {
        enum St { Idle, Ready, Running, SelfAssess, Revealed }

        St st = St.Idle;
        Question q;
        int selected = -1;
        readonly List<int> seq = new List<int>();
        float elapsed, readyT;
        int limit;
        bool hintUsed;
        int lastTick = -1;
        Result result;
        string answerText = "";
        bool shortMismatch;
        bool longOptions;

        // UI
        readonly RectTransform idChipRt, cardRt, boxRt, answerRt, timerRt, fbRt;
        readonly TextMeshProUGUI idText, sectionText, promptText, cardLabel, boxLabel, boxText, passText, fbText, timeText, timeSub, keyHint;
        readonly Btn pauseBtn, fontMinus, fontPlus, actionBtn;
        readonly ScrollRect passScroll, fbScroll;
        readonly FlowLayout flow;
        readonly Image ringFill, ringBg;
        readonly CanvasGroup cardGroup;
        readonly List<Btn> optBtns = new List<Btn>();
        TextMeshProUGUI orderSlots, helpText;
        Btn undoBtn;
        TMP_InputField input;
        float W, H;
        bool portrait;

        public QuizView(F2RApp app) : base(app, "QuizView")
        {
            var chip = UI.Card(root, "IdChip", Palette.Cyan.A(0.16f), Palette.Edge, 12);
            idChipRt = chip.rectTransform;
            idText = UI.Text(idChipRt, "", 20, Palette.CyanSoft, TextAlignmentOptions.Center, true);
            UI.Stretch(idText.rectTransform, 8, 0, 8, 0);
            sectionText = UI.Text(root, "", 19, Palette.TextMuted, TextAlignmentOptions.MidlineLeft, false, "Section");
            sectionText.textWrappingMode = TextWrappingModes.NoWrap; sectionText.overflowMode = TextOverflowModes.Ellipsis;
            pauseBtn = UI.Button(root, "일시정지", 18, BtnStyle.Chip, OpenPause, "Pause");
            promptText = UI.Text(root, "", 24, Palette.White, TextAlignmentOptions.TopLeft, true, "Prompt");
            promptText.lineSpacing = 4;

            var card = UI.Panel(root, Palette.Paper, 20, "PassageCard");
            cardRt = card.rectTransform;
            UI.Outline(cardRt, Palette.Edge.A(0.9f), 20);
            UI.Glow(cardRt, Palette.Cyan.A(0.22f), 16).transform.SetAsFirstSibling();
            cardGroup = cardRt.gameObject.AddComponent<CanvasGroup>();
            cardLabel = UI.Text(cardRt, "READ THE PASSAGE · 지문", 16, Palette.Hex("#0891B2"), TextAlignmentOptions.MidlineLeft, true, "Label");
            cardLabel.characterSpacing = 3;
            fontMinus = UI.Button(cardRt, "가−", 18, BtnStyle.Chip, () => ChangeFont(-1), "FontMinus");
            fontPlus = UI.Button(cardRt, "가+", 18, BtnStyle.Chip, () => ChangeFont(1), "FontPlus");

            var box = UI.Panel(cardRt, Palette.Hex("#E2F6FD"), 14, "Box");
            boxRt = box.rectTransform;
            UI.Outline(boxRt, Palette.Hex("#22D3EEAA"), 14);
            boxLabel = UI.Text(boxRt, "", 16, Palette.Hex("#0B4F9C"), TextAlignmentOptions.MidlineLeft, true, "BoxLabel");
            boxText = UI.Text(boxRt, "", 26, Palette.Ink, TextAlignmentOptions.TopLeft, false, "BoxText");
            boxText.enableAutoSizing = true; boxText.fontSizeMin = 15;
            boxText.lineSpacing = 12;
            boxText.raycastTarget = true;
            var boxLinks = boxText.gameObject.AddComponent<LinkClick>(); boxLinks.text = boxText; boxLinks.onLink = OnLink;

            passScroll = UI.Scroll(cardRt, "PassageScroll", out var pc, 50);
            UI.VStack(pc, 0, new RectOffset(18, 26, 6, 30));
            passText = UI.Text(pc, "", 30, Palette.Ink, TextAlignmentOptions.TopLeft, false, "Passage");
            passText.lineSpacing = 22; passText.paragraphSpacing = 26;
            passText.raycastTarget = true;
            var links = passText.gameObject.AddComponent<LinkClick>(); links.text = passText; links.onLink = OnLink;

            var fb = UI.Card(root, "Feedback", Palette.Hex("#0B2459F2"), Palette.Edge, 20);
            fbRt = fb.rectTransform;
            fbScroll = UI.Scroll(fbRt, "FeedbackScroll", out var fc, 50);
            UI.Stretch((RectTransform)fbScroll.transform, 6, 8, 6, 8);
            UI.VStack(fc, 0, new RectOffset(18, 24, 10, 20));
            fbText = UI.Text(fc, "", 23, Palette.White, TextAlignmentOptions.TopLeft, false, "FeedbackText");
            fbText.lineSpacing = 10; fbText.paragraphSpacing = 8;
            fbRt.gameObject.SetActive(false);

            answerRt = UI.Rect("Answers", root);
            flow = answerRt.gameObject.AddComponent<FlowLayout>();
            flow.spacingX = 14; flow.spacingY = 12;
            flow.childAlignment = TextAnchor.UpperLeft;

            timerRt = UI.Rect("Timer", root);
            timerRt.gameObject.AddComponent<Canvas>();   // ring updates every frame; keep it out of the main batch
            ringBg = timerRt.gameObject.AddComponent<Image>(); ringBg.sprite = Art.Ring; ringBg.color = Palette.Cyan.A(0.15f); ringBg.raycastTarget = false;
            var rf = UI.Rect("Fill", timerRt); UI.Stretch(rf);
            ringFill = rf.gameObject.AddComponent<Image>(); ringFill.sprite = Art.Ring; ringFill.type = Image.Type.Filled;
            ringFill.fillMethod = Image.FillMethod.Radial360; ringFill.fillOrigin = (int)Image.Origin360.Top; ringFill.fillClockwise = false;
            ringFill.color = Palette.Cyan; ringFill.raycastTarget = false;
            timeText = UI.Text(timerRt, "", 30, Palette.White, TextAlignmentOptions.Center, true, "Time");
            UI.Stretch(timeText.rectTransform, 0, 0, 0, 18);
            timeSub = UI.Text(timerRt, "", 16, Palette.TextMuted, TextAlignmentOptions.Center, false, "Sub");
            UI.Stretch(timeSub.rectTransform, 0, 52, 0, 0);

            actionBtn = UI.Button(root, "제출하기", 25, BtnStyle.Primary, OnAction, "Action");
            keyHint = UI.Text(root, "", 15, Palette.TextMuted, TextAlignmentOptions.TopLeft, false, "KeyHint");
            root.gameObject.SetActive(false);   // shown once the first question is ready (after the intro clip)
        }

        // ---------------- Question setup ----------------
        public void ShowCurrent()
        {
            root.gameObject.SetActive(true);
            var s = app.Session;
            var item = s.items[s.index];
            q = app.bank.byId[item.id];
            selected = -1; seq.Clear(); elapsed = 0; hintUsed = false; lastTick = -1; answerText = ""; shortMismatch = false;
            longOptions = q.kind == QKind.Choice && (q.options.Any(x => x.Length > 80) || q.options.Sum(x => x.Length) > 220);
            limit = s.timerSec;
            st = St.Ready; readyT = 0.5f;
            cardGroup.alpha = 0;
            var ch = app.bank.GetChapter(q.chapter);
            idText.text = q.id;
            sectionText.text = $"{q.sourceId}. {q.sectionTitle}  <color=#5F7BB0>·</color>  {SectionInfo.Name(q.section)}" + (ch != null && ch.title.Length > 0 ? $"  <color=#5F7BB0>·</color>  {ch.title}" : "");
            promptText.text = PassageRenderer.Esc(q.prompt);
            boxLabel.text = q.boxLabel ?? "";
            fbRt.gameObject.SetActive(false);
            BuildAnswers();
            Render();
            app.tutor.Say(TutorLines.Start(q));
            app.tutor.SetHint(true);
            app.top.Refresh();
            UpdateTimer();
            UpdateAction();
            Layout(W, H, portrait);
            passScroll.verticalNormalizedPosition = 1;
            ScrollToLink("tgt");
        }

        void ClearAnswers()
        {
            foreach (Transform c in answerRt) Object.Destroy(c.gameObject);
            answerRt.DetachChildren();
            optBtns.Clear(); orderSlots = null; helpText = null; input = null; undoBtn = null;
        }

        void BuildAnswers()
        {
            ClearAnswers();
            switch (q.kind)
            {
                case QKind.Order:
                    orderSlots = UI.Text(answerRt, "", 24, Palette.White, TextAlignmentOptions.MidlineLeft, true, "Slots");
                    UI.Size(orderSlots.gameObject, -1, 46, 1);
                    for (int i = 0; i < q.options.Count; i++) AddOption(i, q.options[i]);
                    undoBtn = UI.Button(answerRt, "되돌리기", 20, BtnStyle.Ghost, UndoOrder, "Undo");
                    UI.Size(undoBtn.go, UI.PreferredWidth(undoBtn, 22), 64);
                    UpdateSlots();
                    break;
                case QKind.Short:
                    input = UI.Input(answerRt, "본문에서 찾은 영어 표현을 입력하세요", 24);
                    UI.Size(input.gameObject, -1, 64, 1);
                    input.onSubmit.AddListener(_ => OnAction());
                    break;
                case QKind.Descriptive:
                    helpText = UI.Text(answerRt, "답을 머릿속이나 노트에 정리한 뒤 <b>모범답안 확인</b>을 누르세요. 아래 메모 칸은 선택 사항이에요.", 20, Palette.TextMuted, TextAlignmentOptions.TopLeft, false, "Help");
                    UI.Size(helpText.gameObject, -1, 30, 1);
                    input = UI.Input(answerRt, "메모 (선택)", 22);
                    UI.Size(input.gameObject, -1, 58, 1);
                    break;
                default:
                    for (int i = 0; i < q.options.Count; i++) AddOption(i, longOptions ? Circled.Of(i + 1) : q.options[i]);
                    break;
            }
        }

        void AddOption(int i, string label)
        {
            int idx = i;
            float size = q.kind == QKind.Insert ? 32 : 26;
            var b = UI.Button(answerRt, PassageRenderer.Esc(label), size, BtnStyle.Option, () => Select(idx), "Option" + i);
            b.tag = i;
            optBtns.Add(b);
        }

        void SizeOptions(float width)
        {
            foreach (var b in optBtns)
            {
                float w = UI.PreferredWidth(b, 28, q.kind == QKind.Order ? 110 : 120);
                if (w > width) { float h = b.label.GetPreferredValues(b.label.text, width - 40, 0).y + 26; UI.Size(b.go, width, Mathf.Max(portrait ? 96 : 64, h), 1); }
                else UI.Size(b.go, w, portrait ? 96 : 64);
            }
            if (helpText != null) UI.Size(helpText.gameObject, -1, helpText.GetPreferredValues(helpText.text, width, 0).y + 4, 1);
            if (orderSlots != null) UI.Size(orderSlots.gameObject, -1, 46, 1);
        }

        // ---------------- Rendering ----------------
        bool Revealed => st == St.Revealed || st == St.SelfAssess;

        void Render()
        {
            passText.fontSize = app.PassageFont;
            boxText.fontSizeMax = app.PassageFont - 2; boxText.fontSize = app.PassageFont - 2;
            if (q.kind == QKind.Order) passText.text = PassageRenderer.RenderOrder(q, st == St.Revealed);
            else passText.text = PassageRenderer.Render(q, q.passage, selected, st == St.Revealed);
            bool hasBox = q.box != null && !(q.kind == QKind.Insert && st == St.Revealed);
            bool inlineBox = hasBox && PassageRenderer.PlainBox(q).Length > 140;
            boxRt.gameObject.SetActive(hasBox && !inlineBox);
            if (hasBox)
            {
                string renderedBox = PassageRenderer.Render(q, q.box, selected, st == St.Revealed);
                if (inlineBox) passText.text = "<b><color=#0891B2>" + PassageRenderer.Esc(q.boxLabel) + "</color></b>\n" + renderedBox + "\n\n<b><color=#0891B2>본문</color></b>\n" + passText.text;
                else boxText.text = renderedBox;
            }
            if (longOptions)
            {
                passText.text += "\n\n<b><color=#0891B2>보기 · 아래 번호 버튼으로 선택하세요</color></b>";
                for (int i = 0; i < q.options.Count; i++)
                {
                    string option = PassageRenderer.Esc(q.options[i]);
                    if (st == St.Revealed && i == q.correctIndex) option = "<b><color=#047857>" + option + "</color></b>";
                    else if (i == selected) option = "<b><color=#0B4F9C>" + option + "</color></b>";
                    passText.text += "\n\n<link=\"opt" + i + "\">" + option + "</link>";
                }
            }
            cardLabel.text = q.kind == QKind.Order ? "READ THE PASSAGE · 주어진 글과 (A)(B)(C)" : "READ THE PASSAGE · 지문";
        }

        void RefreshButtons()
        {
            for (int i = 0; i < optBtns.Count; i++)
            {
                var b = optBtns[i];
                if (q.kind == QKind.Order)
                {
                    if (st == St.Revealed) b.SetState(BtnState.Dim);
                    else b.SetState(seq.Contains(i) ? BtnState.Dim : BtnState.Normal);
                    b.Interactable = st == St.Running || st == St.Ready;
                    continue;
                }
                if (b.tag is int oi)
                {
                    if (st == St.Revealed && q.correctIndex >= 0)
                        b.SetState(oi == q.correctIndex ? BtnState.Correct : oi == selected ? BtnState.Wrong : BtnState.Dim);
                    else if (st == St.Revealed || st == St.SelfAssess) { }
                    else b.SetState(oi == selected ? BtnState.Selected : BtnState.Normal);
                    b.Interactable = st == St.Running || st == St.Ready || (st == St.SelfAssess && b.style != BtnStyle.Option);
                }
            }
            if (undoBtn != null) undoBtn.go.SetActive(st != St.Revealed);
            UpdateSlots();
        }

        void UpdateSlots()
        {
            if (orderSlots == null) return;
            var sb = new StringBuilder("<color=#9FB4DA>내 순서</color>   ");
            for (int i = 0; i < q.options.Count; i++)
            {
                if (i > 0) sb.Append("  <color=#5F7BB0>→</color>  ");
                if (i < seq.Count)
                {
                    string col = st == St.Revealed ? (q.correctOrder.Count > i && q.correctOrder[i] == seq[i] ? "#2BD99B" : "#FF6B88") : "#22D3EE";
                    sb.Append($"<color={col}>{q.options[seq[i]]}</color>");
                }
                else sb.Append("<color=#3A4E7A>( ? )</color>");
            }
            if (st == St.Revealed) sb.Append($"     <color=#9FB4DA>정답</color> <color=#2BD99B>{q.answerDisplay}</color>");
            orderSlots.text = sb.ToString();
        }

        void UpdateAction()
        {
            bool last = app.Session.index >= app.Session.items.Count - 1;
            switch (st)
            {
                case St.Revealed:
                    actionBtn.go.SetActive(true);
                    actionBtn.SetLabel(last ? "결과 보기 →" : "다음 문제 →");
                    actionBtn.Interactable = true;
                    break;
                case St.SelfAssess:
                    actionBtn.go.SetActive(false);
                    break;
                default:
                    actionBtn.go.SetActive(true);
                    actionBtn.SetLabel(q.kind == QKind.Descriptive ? "모범답안 확인" : "제출하기");
                    actionBtn.Interactable = CanSubmit();
                    break;
            }
            actionBtn.SetState(actionBtn.Interactable ? BtnState.Normal : BtnState.Dim);
            string keys = q.kind == QKind.Order ? "1–3 선택 · Backspace 취소" :
                q.kind == QKind.TrueFalse ? "T/F 또는 1·2 선택" :
                q.kind == QKind.Short || q.kind == QKind.Descriptive ? "입력 후 Enter" : $"1–{Mathf.Min(9, q.options.Count)} 선택 · Enter 제출";
            keyHint.text = st == St.Revealed ? "Enter 다음 문제" : st == St.SelfAssess ? "1 맞게 썼어요 · 2 못 썼어요" : $"{keys}\nH 힌트 · Esc 일시정지";
            if (app.mobile) keyHint.text = "";   // touch devices: no keyboard shortcuts to advertise
        }

        bool CanSubmit()
        {
            if (!(st == St.Running || st == St.Ready)) return false;
            switch (q.kind)
            {
                case QKind.Order: return seq.Count == q.options.Count;
                case QKind.Short: return input != null && input.text.Trim().Length > 0;
                case QKind.Descriptive: return true;
                default: return selected >= 0;
            }
        }

        // ---------------- Interaction ----------------
        void StartIfReady() { if (st == St.Ready && !app.Paused) { st = St.Running; cardGroup.alpha = 1; } }

        void Select(int i)
        {
            StartIfReady();
            if (st != St.Running || i < 0 || i >= q.options.Count) return;
            if (q.kind == QKind.Order)
            {
                if (seq.Contains(i)) return;
                seq.Add(i);
            }
            else if (q.kind == QKind.Short || q.kind == QKind.Descriptive) return;
            else selected = i;
            app.sfx.Play("select");
            Render(); RefreshButtons(); UpdateAction();
        }

        void UndoOrder()
        {
            if (st != St.Running || seq.Count == 0) return;
            seq.RemoveAt(seq.Count - 1);
            RefreshButtons(); UpdateAction();
        }

        void OnLink(string id)
        {
            if (id.StartsWith("opt") && int.TryParse(id.Substring(3), out int i)) Select(i);
        }

        int lastActionFrame = -1;

        void OnAction()
        {
            // Enter can arrive from both the input field's submit and the global key handler in one frame.
            if (Time.frameCount == lastActionFrame) return;
            lastActionFrame = Time.frameCount;
            if (st == St.Revealed) { app.Advance(this); return; }
            StartIfReady();
            if (!CanSubmit()) return;
            float t = elapsed;
            switch (q.kind)
            {
                case QKind.Order:
                    answerText = string.Join("-", seq.Select(i => q.options[i]));
                    Finish(seq.SequenceEqual(q.correctOrder) ? Result.Correct : Result.Wrong, t);
                    break;
                case QKind.Short:
                    answerText = input.text.Trim();
                    if (q.accepted.Any(a => Norm(a) == Norm(answerText))) Finish(Result.Correct, t);
                    else { shortMismatch = true; EnterSelfAssess(); }
                    break;
                case QKind.Descriptive:
                    answerText = input != null && input.text.Trim().Length > 0 ? input.text.Trim() : "(서술 · 자기평가)";
                    EnterSelfAssess();
                    break;
                default:
                    answerText = q.options[selected];
                    Finish(selected == q.correctIndex ? Result.Correct : Result.Wrong, t);
                    break;
            }
        }

        static string Norm(string s) => Regex.Replace(Regex.Replace(s.ToLowerInvariant().Replace("’", "'"), @"[^a-z0-9' ]", " "), @"\s+", " ").Trim();

        void EnterSelfAssess()
        {
            st = St.SelfAssess;
            if (input != null) input.interactable = false;
            ClearAnswers();
            var yes = UI.Button(answerRt, shortMismatch ? "의미상 맞게 썼어요 (자기평가)" : "맞게 썼어요 (자기평가)", 22, BtnStyle.Soft, () => Finish(Result.SelfCorrect, elapsed), "Yes");
            var no = UI.Button(answerRt, "못 썼어요 / 틀렸어요", 22, BtnStyle.Ghost, () => Finish(Result.SelfWrong, elapsed), "No");
            foreach (var b in new[] { yes, no }) UI.Size(b.go, UI.PreferredWidth(b, 26), 64);
            ShowFeedback(Result.None, 0);
            app.tutor.Say(shortMismatch ? "입력한 답이 모범답안과 글자가 달라요. 같은 대상을 가리키는지 비교해서 스스로 판단해 주세요." : TutorLines.SelfCheck());
            UpdateAction();
            Layout(W, H, portrait);
        }

        void Timeout()
        {
            answerText = "(시간 초과)";
            app.sfx.Play("timeout");
            if (input != null) input.interactable = false;
            Finish(Result.Unanswered, limit);
        }

        void Finish(Result r, float time)
        {
            result = r;
            bool wasSelf = st == St.SelfAssess;
            st = St.Revealed;
            if (wasSelf) ClearAnswers();
            int pts = app.Record(q, r, answerText, time, hintUsed);
            if (r == Result.Correct) { app.sfx.Play("correct"); app.tutor.Say(TutorLines.Correct(app.Session.streak)); }
            else if (r == Result.SelfCorrect) { app.sfx.Play("correct"); app.tutor.Say("스스로 점검한 것도 실력이에요. 모범답안의 표현을 한 번 더 읽어 봐요."); }
            else if (r == Result.Unanswered) app.tutor.Say(TutorLines.Timeout());
            else { app.sfx.Play("wrong"); app.tutor.Say(TutorLines.Wrong()); }
            app.tutor.SetHint(false);
            cardGroup.alpha = 1;
            Render();
            RefreshButtons();
            ShowFeedback(r, pts);
            UpdateAction();
            UpdateTimer();
            app.top.Refresh();
            Layout(W, H, portrait);
            if (q.kind == QKind.Insert || q.kind == QKind.PickNumber) ScrollToLink("opt" + q.correctIndex);
            else ScrollToLink("tgt");
        }

        void ShowFeedback(Result r, int pts)
        {
            var sb = new StringBuilder();
            switch (r)
            {
                case Result.Correct: sb.Append($"<size=125%><b><color=#2BD99B>정답이에요!</color></b>  <color=#FFC24B>+{pts} XP</color></size>"); break;
                case Result.Wrong: sb.Append("<size=125%><b><color=#FF6B88>오답이에요</color></b></size>  <color=#9FB4DA>오답 노트에 담았어요</color>"); break;
                case Result.Unanswered: sb.Append("<size=125%><b><color=#FFC24B>시간 초과</color></b></size>  <color=#9FB4DA>미응답으로 기록했어요</color>"); break;
                case Result.SelfCorrect: sb.Append($"<size=125%><b><color=#2BD99B>자기평가: 맞음</color></b>  <color=#FFC24B>+{pts} XP</color></size>"); break;
                case Result.SelfWrong: sb.Append("<size=125%><b><color=#FF6B88>자기평가: 다시 복습</color></b></size>  <color=#9FB4DA>오답 노트에 담았어요</color>"); break;
                default: sb.Append("<size=125%><b><color=#8BEAFF>모범답안과 비교해 보세요</color></b></size>"); break;
            }
            sb.Append("\n");
            if (q.kind == QKind.Descriptive || q.kind == QKind.Short)
            {
                sb.Append($"<color=#9FB4DA>내 답</color>  {PassageRenderer.Esc(answerText)}\n");
                sb.Append($"<color=#9FB4DA>모범답안</color>  <b><color=#2BD99B>{PassageRenderer.Esc(q.modelAnswer)}</color></b>");
            }
            else
                sb.Append($"<color=#9FB4DA>내 답</color>  {PassageRenderer.Esc(answerText)}     <color=#9FB4DA>정답</color>  <b><color=#2BD99B>{PassageRenderer.Esc(q.answerDisplay)}</color></b>");
            if (r != Result.None) sb.Append($"     <color=#9FB4DA>풀이 시간</color>  {Fmt(r == Result.Unanswered ? limit : elapsed)}");
            sb.Append("\n");
            sb.Append("\n<b><color=#8BEAFF>■ SUNI · 수니 해설</color></b>\n");
            sb.Append(PassageRenderer.Esc(string.IsNullOrEmpty(q.explanation) ? $"정답은 '{q.answerDisplay}'예요. 지문의 표시된 부분과 앞뒤 문장을 다시 읽으며 근거를 확인해 보세요." : q.explanation));
            if (!string.IsNullOrEmpty(q.sourceNotice)) sb.Append("\n\n<b><color=#FFC24B>■ 원본 확인 안내</color></b>\n").Append(PassageRenderer.Esc(q.sourceNotice));
            var sentence = PassageRenderer.CorrectSentence(q);
            if (!string.IsNullOrEmpty(sentence)) sb.Append("\n\n<b><color=#8BEAFF>■ 정답 문장</color></b>\n").Append(sentence);
            var vocab = q.vocab.Count > 0 ? q.vocab : app.bank.GetChapter(q.chapter)?.vocab.Take(6).ToList();
            if (vocab != null && vocab.Count > 0)
                sb.Append("\n\n<b><color=#8BEAFF>■ 핵심 어휘</color></b>\n").Append(string.Join("\n", vocab.Select(v => "· " + PassageRenderer.Esc(v).Replace(" = ", "  <color=#9FB4DA>—</color>  "))));
            if (hintUsed) sb.Append("\n\n<size=85%><color=#9FB4DA>이 문항에서 SUNI · 수니 힌트를 사용했어요.</color></size>");
            fbText.text = sb.ToString();
            fbRt.gameObject.SetActive(true);
            fbScroll.verticalNormalizedPosition = 1;
        }

        public override void OnHint()
        {
            if (q == null) return;
            if (st == St.Revealed) { app.tutor.Say("해설 카드의 '정답 문장'을 소리 내어 읽어 보세요. 다음 문제로 가려면 '다음 문제 →'를 눌러요."); return; }
            StartIfReady();
            hintUsed = true;
            app.tutor.Say("<color=#FFC24B><b>힌트</b></color>  " + PassageRenderer.Esc(string.IsNullOrEmpty(q.hint) ? TutorLines.GenericHint(q) : q.hint));
        }

        void ChangeFont(int d)
        {
            app.save.fontStep = Mathf.Clamp(app.save.fontStep + d, 0, F2RApp.FontSizes.Length - 1);
            app.Persist();
            Render();
            Layout(W, H, portrait);
        }

        void OpenPause()
        {
            if (app.modal.IsOpen) return;
            app.tutor.Say(TutorLines.Paused());
            app.modal.Show("일시정지", "타이머가 멈춰 있어요.\n홈으로 가도 진행 상황은 저장되고, 홈 화면의 <b>이어하기</b>로 계속할 수 있어요.\n<size=85%><color=#9FB4DA>※ 풀던 문항은 다시 열면 처음부터 시간이 시작돼요.</color></size>", null,
                ("홈으로 (진행 저장)", BtnStyle.Ghost, app.ExitToHome),
                ("계속하기", BtnStyle.Primary, null));
        }

        public void AskExit() => OpenPause();

        public override void OnKey(Key k)
        {
            if (q == null) return;
            if (k == Key.Pause) { if (st == St.Running || st == St.Ready) OpenPause(); return; }
            if (k == Key.Escape) { OpenPause(); return; }
            if (k == Key.Enter || k == Key.NumpadEnter) { OnAction(); return; }
            if (k == Key.H) { OnHint(); return; }
            if (k == Key.Backspace) { UndoOrder(); return; }
            if (k == Key.UpArrow || k == Key.PageUp) { ScrollBy(k == Key.PageUp ? 0.6f : 0.15f); return; }
            if (k == Key.DownArrow || k == Key.PageDown) { ScrollBy(k == Key.PageDown ? -0.6f : -0.15f); return; }
            if (q.kind == QKind.TrueFalse && (k == Key.T || k == Key.F)) { Select(k == Key.T ? 0 : 1); return; }
            int n = -1;
            if (k >= Key.Digit1 && k <= Key.Digit9) n = k - Key.Digit1;
            else if (k == Key.Digit0) n = 9;
            else if (k >= Key.Numpad1 && k <= Key.Numpad9) n = k - Key.Numpad1;
            if (n >= 0 && st == St.SelfAssess)
            {
                if (n == 0) Finish(Result.SelfCorrect, elapsed);
                else if (n == 1) Finish(Result.SelfWrong, elapsed);
                return;
            }
            if (n >= 0) Select(n);
        }

        void ScrollBy(float viewports)
        {
            var c = passScroll.content; var v = passScroll.viewport;
            float range = c.rect.height - v.rect.height;
            if (range <= 0) return;
            passScroll.verticalNormalizedPosition = Mathf.Clamp01(passScroll.verticalNormalizedPosition + viewports * v.rect.height / range);
        }

        void ScrollToLink(string id)
        {
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(passScroll.content);
            passText.ForceMeshUpdate();
            var ti = passText.textInfo;
            for (int i = 0; i < ti.linkCount; i++)
            {
                if (ti.linkInfo[i].GetLinkID() != id) continue;
                int ci = ti.linkInfo[i].linkTextfirstCharacterIndex;
                if (ci < 0 || ci >= ti.characterCount) return;
                var world = passText.transform.TransformPoint(ti.characterInfo[ci].topLeft);
                var local = passScroll.content.InverseTransformPoint(world);
                float offset = -local.y;
                float range = passScroll.content.rect.height - passScroll.viewport.rect.height;
                if (range <= 0) return;
                float want = Mathf.Clamp(offset - passScroll.viewport.rect.height * 0.3f, 0, range);
                passScroll.verticalNormalizedPosition = 1 - want / range;
                passScroll.velocity = Vector2.zero;
                return;
            }
        }

        // ---------------- Timer ----------------
        public override void Tick(float dt)
        {
            if (q == null) return;
            if (st == St.Ready)
            {
                if (!app.Paused) { readyT -= dt; cardGroup.alpha = Mathf.Clamp01(1 - readyT / 0.5f); }
                if (readyT <= 0 && !app.Paused) { st = St.Running; cardGroup.alpha = 1; }
            }
            else if (st == St.Running && !app.Paused)
            {
                elapsed += dt;
                if (limit > 0)
                {
                    int remain = Mathf.CeilToInt(limit - elapsed);
                    if (remain <= 5 && remain != lastTick && remain > 0) { lastTick = remain; app.sfx.Play("tick"); }
                    if (elapsed >= limit) { elapsed = limit; Timeout(); return; }
                }
                if (q.kind == QKind.Short) { bool can = CanSubmit(); if (can != actionBtn.Interactable) UpdateAction(); }
            }
            UpdateTimer();
        }

        static string Fmt(float s) { int t = Mathf.FloorToInt(s); return $"{t / 60:00}:{t % 60:00}"; }

        void UpdateTimer()
        {
            bool paused = app.Paused && st == St.Running;
            if (limit > 0)
            {
                float remain = Mathf.Max(0, limit - elapsed);
                float frac = remain / limit;
                ringFill.fillAmount = frac;
                ringFill.color = frac > 0.33f ? Palette.Cyan : remain > 10 ? Palette.Amber : Palette.Coral;
                timeText.text = Fmt(Mathf.Ceil(remain));
                timeSub.text = st == St.Ready ? "준비" : paused ? "일시정지" : st == St.Revealed || st == St.SelfAssess ? "정지" : $"/ {Fmt(limit)}";
            }
            else
            {
                ringFill.fillAmount = 1; ringFill.color = Palette.Violet;
                timeText.text = Fmt(elapsed);
                timeSub.text = st == St.Ready ? "준비" : paused ? "일시정지" : "무제한";
            }
        }

        // ---------------- Layout ----------------
        public override void Layout(float w, float h, bool portrait)
        {
            W = w; H = h; this.portrait = portrait;
            if (q == null || w <= 0) return;
            float chipW = idText.GetPreferredValues(idText.text, 1000, 40).x + 30;
            UI.Place(idChipRt, 0, 4, chipW, 38);
            float pw = 118;
            UI.Place(pauseBtn.rt, w - pw, 2, pw, 42);
            UI.Place(sectionText.rectTransform, chipW + 12, 0, w - chipW - pw - 24, 46);
            promptText.fontSize = portrait ? 25 : 24;
            float ph = Mathf.Max(30, promptText.GetPreferredValues(promptText.text, w, 0).y);
            UI.Place(promptText.rectTransform, 2, 54, w - 4, ph);

            float timerS = portrait ? 104 : 128, actW = portrait ? 270 : 214;
            timeText.fontSize = timerS * 0.235f;
            float optsW = portrait ? w : w - timerS - actW - 36;
            SizeOptions(optsW);
            LayoutRebuilder.ForceRebuildLayoutImmediate(answerRt);
            float flowH = flow.HeightFor(optsW);
            float ansH = portrait ? flowH + 14 + timerS : Mathf.Max(flowH, timerS + 4);
            float ay = h - ansH;
            if (portrait)
            {
                UI.Place(answerRt, 0, ay, w, flowH);
                float cy = ay + flowH + 14;
                UI.Place(timerRt, 0, cy, timerS, timerS);
                UI.Place(keyHint.rectTransform, timerS + 16, cy + 8, w - timerS - actW - 32, timerS - 8);
                UI.Place(actionBtn.rt, w - actW, cy + (timerS - 72) / 2, actW, 72);
            }
            else
            {
                UI.Place(answerRt, 0, ay + Mathf.Max(0, (ansH - flowH) / 2 - 8), optsW, flowH);
                UI.Place(timerRt, optsW + 18, ay + (ansH - timerS) / 2, timerS, timerS);
                float ax = w - actW;
                UI.Place(actionBtn.rt, ax, ay + Mathf.Max(0, (ansH - 120) / 2), actW, 72);
                UI.Place(keyHint.rectTransform, ax + 4, ay + Mathf.Max(0, (ansH - 120) / 2) + 80, actW, 44);
            }
            float cardY = 54 + ph + 12;
            float cardH = ay - 14 - cardY;
            bool fb = fbRt.gameObject.activeSelf;
            float share = boxRt.gameObject.activeSelf ? 0.5f : (portrait ? 0.45f : 0.42f);
            float passH = fb ? Mathf.Max(170, cardH * share) : cardH;
            UI.Place(cardRt, 0, cardY, w, passH);
            if (fb) UI.Place(fbRt, 0, cardY + passH + 10, w, Mathf.Max(80, cardH - passH - 10));
            LayoutCard(w, passH);
        }

        void LayoutCard(float w, float h)
        {
            UI.Place(cardLabel.rectTransform, 22, 8, w - 200, 34);
            UI.Place(fontPlus.rt, w - 16 - 64, 8, 64, 36);
            UI.Place(fontMinus.rt, w - 16 - 64 * 2 - 8, 8, 64, 36);
            float y = 50;
            if (boxRt.gameObject.activeSelf)
            {
                float inner = w - 32 - 36;
                float pref = boxText.GetPreferredValues(boxText.text, inner, 0).y;
                float bh = Mathf.Min(pref + 52, h * 0.45f);
                UI.Place(boxRt, 16, y, w - 32, bh);
                UI.Place(boxLabel.rectTransform, 18, 6, inner, 28);
                UI.Place(boxText.rectTransform, 18, 36, inner, bh - 44);
                y += bh + 8;
            }
            UI.Place((RectTransform)passScroll.transform, 6, y, w - 12, Mathf.Max(40, h - y - 8));
        }
    }
}
