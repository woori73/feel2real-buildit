using System.Collections.Generic;
using UnityEngine;

namespace F2R
{
    public static class Palette
    {
        public static readonly Color NavyDeep = Hex("#050F2C");
        public static readonly Color Navy = Hex("#0B1E4A");
        public static readonly Color Panel = Hex("#0E2A62E6");
        public static readonly Color PanelSoft = Hex("#14367AD9");
        public static readonly Color Edge = Hex("#2BD4FF");
        public static readonly Color EdgeSoft = Hex("#2BD4FF66");
        public static readonly Color Cyan = Hex("#22D3EE");
        public static readonly Color CyanSoft = Hex("#8BEAFF");
        public static readonly Color White = Hex("#F4F8FF");
        public static readonly Color Paper = Hex("#F6F9FF");
        public static readonly Color Ink = Hex("#10224A");
        public static readonly Color InkMuted = Hex("#5D6F96");
        public static readonly Color TextMuted = Hex("#9FB4DA");
        public static readonly Color Green = Hex("#2BD99B");
        public static readonly Color Coral = Hex("#FF6B88");
        public static readonly Color Amber = Hex("#FFC24B");
        public static readonly Color Violet = Hex("#A78BFA");
        public static readonly Color Grey = Hex("#3A4E7A");

        public static Color Hex(string h) { ColorUtility.TryParseHtmlString(h, out var c); return c; }
        public static Color A(this Color c, float a) { c.a = a; return c; }

        public static Color ForResult(Result r)
        {
            switch (r)
            {
                case Result.Correct: return Cyan;
                case Result.SelfCorrect: return Green;
                case Result.Wrong: case Result.SelfWrong: return Coral;
                case Result.Unanswered: return Amber;
                default: return Grey;
            }
        }
    }

    /// <summary>All sprites and textures are generated at startup; no image assets besides the F2R logo.</summary>
    public static class Art
    {
        static readonly Dictionary<string, Sprite> cache = new Dictionary<string, Sprite>();
        public const int R = 32;

        static Texture2D NewTex(int w, int h, TextureWrapMode wrap = TextureWrapMode.Clamp)
        {
            var t = new Texture2D(w, h, TextureFormat.RGBA32, false) { wrapMode = wrap, filterMode = FilterMode.Bilinear };
            return t;
        }

        static float RoundRectDist(float x, float y, float w, float h, float r)
        {
            float qx = Mathf.Abs(x - w / 2f) - (w / 2f - r);
            float qy = Mathf.Abs(y - h / 2f) - (h / 2f - r);
            float ox = Mathf.Max(qx, 0), oy = Mathf.Max(qy, 0);
            return Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(qx, qy), 0) - r;
        }

        static Sprite Sliced(string key, int size, int border, System.Func<float, float, float> alpha)
        {
            if (cache.TryGetValue(key, out var s)) return s;
            var t = NewTex(size, size);
            var px = new Color32[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(Mathf.Clamp01(alpha(x + 0.5f, y + 0.5f)) * 255));
            t.SetPixels32(px); t.Apply(false, true);
            s = Sprite.Create(t, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100, 0, SpriteMeshType.FullRect, new Vector4(border, border, border, border));
            cache[key] = s;
            return s;
        }

        public static Sprite Round => Sliced("round", R * 2 + 4, R + 1, (x, y) => 0.5f - RoundRectDist(x, y, R * 2 + 4, R * 2 + 4, R));
        public static Sprite Outline => Sliced("outline", R * 2 + 4, R + 1, (x, y) =>
        {
            float d = RoundRectDist(x, y, R * 2 + 4, R * 2 + 4, R);
            return Mathf.Clamp01(0.5f - d) * Mathf.Clamp01(d + 3.5f);
        });
        public static Sprite Glow => Sliced("glow", 128, 60, (x, y) =>
        {
            // Outer halo only: transparent inside so it never tints the panel it surrounds.
            float d = RoundRectDist(x, y, 128, 128, 40) + 24;
            if (d <= 0) return 0;
            return Mathf.Pow(1 - Mathf.Clamp01(d / 24f), 2.2f) * 0.9f * Mathf.Clamp01(d / 3f);
        });

        public static Sprite Disc
        {
            get
            {
                if (cache.TryGetValue("disc", out var s)) return s;
                int n = 64; var t = NewTex(n, n); var px = new Color32[n * n];
                for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                    {
                        float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(n / 2f, n / 2f));
                        px[y * n + x] = new Color32(255, 255, 255, (byte)(Mathf.Clamp01(n / 2f - 1 - d) * 255));
                    }
                t.SetPixels32(px); t.Apply(false, true);
                return cache["disc"] = Sprite.Create(t, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100);
            }
        }

        public static Sprite Ring
        {
            get
            {
                if (cache.TryGetValue("ring", out var s)) return s;
                int n = 256; float outer = 126, inner = 108; var t = NewTex(n, n); var px = new Color32[n * n];
                for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                    {
                        float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(n / 2f, n / 2f));
                        float a = Mathf.Clamp01(outer - d) * Mathf.Clamp01(d - inner);
                        px[y * n + x] = new Color32(255, 255, 255, (byte)(a * 255));
                    }
                t.SetPixels32(px); t.Apply(false, true);
                return cache["ring"] = Sprite.Create(t, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100);
            }
        }

        public static Texture2D Background()
        {
            var t = NewTex(4, 256);
            var top = Palette.Hex("#0B2A6B"); var mid = Palette.Hex("#081C4C"); var bot = Palette.Hex("#040C26");
            for (int y = 0; y < 256; y++)
            {
                float v = y / 255f;
                var c = v > 0.5f ? Color.Lerp(mid, top, (v - 0.5f) * 2) : Color.Lerp(bot, mid, v * 2);
                for (int x = 0; x < 4; x++) t.SetPixel(x, y, c);
            }
            t.Apply();
            return t;
        }

        public static Texture2D Grid()
        {
            int n = 96; var t = NewTex(n, n, TextureWrapMode.Repeat); var px = new Color32[n * n];
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                {
                    bool line = x == 0 || y == 0;
                    bool dot = (x == 0 && y == 0);
                    byte a = (byte)(dot ? 70 : line ? 22 : 0);
                    px[y * n + x] = new Color32(70, 210, 255, a);
                }
            t.SetPixels32(px); t.Apply();
            return t;
        }

        /// <summary>Non-face holographic emblem used only while the authentic SUNI image is not available.</summary>
        public static Texture2D PortraitPlaceholder()
        {
            int n = 256; var t = NewTex(n, n); var px = new Color32[n * n];
            var c0 = Palette.Hex("#1B5FD6"); var c1 = Palette.Hex("#0A1E52");
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
                {
                    float dx = x - n / 2f, dy = y - n / 2f;
                    float d = Mathf.Sqrt(dx * dx + dy * dy) / (n / 2f);
                    var c = Color.Lerp(c0, c1, Mathf.Clamp01(d));
                    float ring = Mathf.Abs(Mathf.Repeat(d * 6f, 1f) - 0.5f);
                    if (ring < 0.03f && d < 0.95f) c = Color.Lerp(c, Palette.Cyan, 0.35f);
                    if ((x % 16 == 0 || y % 16 == 0)) c = Color.Lerp(c, Palette.Cyan, 0.08f);
                    px[y * n + x] = c;
                }
            t.SetPixels32(px); t.Apply();
            return t;
        }
    }

    /// <summary>Procedural sound effects (short synthesized tones).</summary>
    public class Sfx
    {
        readonly AudioSource src;
        readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
        public bool enabled = true;
        const int Rate = 22050;

        public Sfx(GameObject host)
        {
            src = host.AddComponent<AudioSource>();
            src.playOnAwake = false;
            clips["click"] = Tone("click", new[] { 880f }, 0.05f, 0.18f);
            clips["select"] = Tone("select", new[] { 660f, 990f }, 0.07f, 0.16f);
            clips["correct"] = Tone("correct", new[] { 660f, 880f, 1320f }, 0.12f, 0.22f);
            clips["wrong"] = Tone("wrong", new[] { 330f, 247f }, 0.16f, 0.2f);
            clips["timeout"] = Tone("timeout", new[] { 440f, 440f, 294f }, 0.12f, 0.2f);
            clips["tick"] = Tone("tick", new[] { 1200f }, 0.03f, 0.08f);
            clips["reward"] = Tone("reward", new[] { 523f, 659f, 784f, 1047f, 1319f }, 0.11f, 0.2f);
        }

        static AudioClip Tone(string name, float[] notes, float each, float vol)
        {
            int per = (int)(Rate * each);
            var data = new float[per * notes.Length + Rate / 20];
            for (int n = 0; n < notes.Length; n++)
                for (int i = 0; i < per + Rate / 20 && n * per + i < data.Length; i++)
                {
                    float tt = i / (float)Rate;
                    float env = Mathf.Exp(-tt * 18f) * Mathf.Clamp01(i / 60f);
                    data[n * per + i] += vol * env * (Mathf.Sin(2 * Mathf.PI * notes[n] * tt) + 0.3f * Mathf.Sin(4 * Mathf.PI * notes[n] * tt));
                }
            var clip = AudioClip.Create(name, data.Length, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        public void Play(string name)
        {
            if (!enabled || !clips.TryGetValue(name, out var c)) return;
            src.PlayOneShot(c);
        }
    }
}
