using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace F2R
{
    /// <summary>Single modal dialog. While open, the question timer is paused.</summary>
    public class Modal
    {
        readonly F2RApp app;
        readonly RectTransform root, card, btnRow;
        readonly TextMeshProUGUI title, body;
        readonly ScrollRect scroll;
        readonly List<Btn> buttons = new List<Btn>();
        Action onEscape;
        float W = 1600, H = 900;
        public bool IsOpen => root.gameObject.activeSelf;

        public Modal(F2RApp app, Transform parent)
        {
            this.app = app;
            root = UI.Rect("Modal", parent); UI.Stretch(root);
            var scrim = root.gameObject.AddComponent<Image>(); scrim.color = Palette.NavyDeep.A(0.78f);
            var c = UI.Card(root, "Card", Palette.Hex("#0D2659FA"), Palette.Edge, 22);
            card = c.rectTransform;
            UI.Glow(card, Palette.Cyan.A(0.25f), 22).transform.SetAsFirstSibling();
            title = UI.Text(card, "", 30, Palette.White, TextAlignmentOptions.MidlineLeft, true, "Title");
            scroll = UI.Scroll(card, "Body", out var content, 40);
            UI.VStack(content, 0, new RectOffset(4, 16, 4, 8));
            body = UI.Text(content, "", 23, Palette.White, TextAlignmentOptions.TopLeft, false, "BodyText");
            body.lineSpacing = 10;
            btnRow = UI.Rect("Buttons", card);
            root.gameObject.SetActive(false);
        }

        public void Show(string t, string b, Action escape, params (string label, BtnStyle style, Action act)[] btns)
        {
            title.text = t; body.text = b; onEscape = escape;
            foreach (var x in buttons) UnityEngine.Object.Destroy(x.go);
            buttons.Clear();
            foreach (var bt in btns)
            {
                var act = bt.act;
                var btn = UI.Button(btnRow, bt.label, 22, bt.style, () => { Close(); act?.Invoke(); });
                buttons.Add(btn);
            }
            root.gameObject.SetActive(true);
            root.SetAsLastSibling();
            Layout(W, H);
            scroll.verticalNormalizedPosition = 1;
        }

        public void Close() { root.gameObject.SetActive(false); }

        public void Layout(float w, float h)
        {
            W = w; H = h;
            if (!IsOpen) return;
            float cw = Mathf.Min(w - 32, 860);
            float inner = cw - 56;
            float bodyH = body.GetPreferredValues(body.text, inner - 24, 0).y + 16;
            // buttons: wrap into rows
            float rowH = 60, x = 0, rows = 1;
            var widths = new List<float>();
            foreach (var b in buttons) widths.Add(Mathf.Min(inner, UI.PreferredWidth(b, 26, 140)));
            for (int i = 0; i < buttons.Count; i++) { if (x > 0 && x + widths[i] > inner) { rows++; x = 0; } x += widths[i] + 12; }
            float btnH = rows * rowH + (rows - 1) * 10;
            float ch = Mathf.Min(h - 40, 28 + 48 + 14 + bodyH + 18 + btnH + 26);
            UI.Place(card, (w - cw) / 2, (h - ch) / 2, cw, ch);
            UI.Place(title.rectTransform, 28, 22, inner, 48);
            float bh = ch - 22 - 48 - 14 - btnH - 26 - 18;
            UI.Place((RectTransform)scroll.transform, 28, 22 + 48 + 14, inner, Mathf.Max(40, bh));
            UI.Place(btnRow, 28, ch - 26 - btnH, inner, btnH);
            // right-aligned rows
            float y = 0; x = inner; int start = 0;
            var rowsList = new List<List<int>>(); var cur = new List<int>(); float used = 0;
            for (int i = 0; i < buttons.Count; i++)
            {
                if (cur.Count > 0 && used + widths[i] > inner) { rowsList.Add(cur); cur = new List<int>(); used = 0; }
                cur.Add(i); used += widths[i] + 12;
            }
            if (cur.Count > 0) rowsList.Add(cur);
            foreach (var r in rowsList)
            {
                x = inner;
                for (int k = r.Count - 1; k >= 0; k--) { int i = r[k]; x -= widths[i]; UI.Place(buttons[i].rt, x, y, widths[i], rowH); x -= 12; }
                y += rowH + 10;
            }
            start++;
        }

        public void OnKey(Keyboard kb)
        {
            if (kb.escapeKey.wasPressedThisFrame) { var e = onEscape; Close(); e?.Invoke(); }
            else if ((kb.enterKey.wasPressedThisFrame || kb.numpadEnterKey.wasPressedThisFrame) && buttons.Count > 0)
            {
                var b = buttons.Find(x => x.style == BtnStyle.Primary) ?? buttons[buttons.Count - 1];
                b.button.onClick.Invoke();
            }
        }
    }

    public enum ClipKind { Intro, Reward }

    /// <summary>Short skippable, muted holographic clip shown only outside timed solving.</summary>
    public class Clip
    {
        readonly F2RApp app;
        readonly RectTransform root, card, sweep, bar;
        readonly RawImage portrait;
        readonly TextMeshProUGUI title, text, placeholder;
        readonly Image barFill, scrim;
        readonly List<Image> rings = new List<Image>();
        readonly Btn skip;
        Action onDone;
        float t, duration;
        ClipKind kind;
        int textLen;
        public bool Playing => root.gameObject.activeSelf;

        public Clip(F2RApp app, Transform parent)
        {
            this.app = app;
            root = UI.Rect("Clip", parent); UI.Stretch(root);
            scrim = root.gameObject.AddComponent<Image>(); scrim.color = Palette.NavyDeep.A(0.85f);
            for (int i = 0; i < 3; i++)
            {
                var r = UI.Rect("Ring", root);
                var img = r.gameObject.AddComponent<Image>(); img.sprite = Art.Ring; img.raycastTarget = false;
                r.anchorMin = r.anchorMax = new Vector2(0.5f, 0.5f);
                rings.Add(img);
            }
            var c = UI.Card(root, "Card", Palette.Hex("#0D2E6EF5"), Palette.Edge, 24);
            card = c.rectTransform;
            UI.Glow(card, Palette.Cyan.A(0.35f), 26).transform.SetAsFirstSibling();
            var pf = UI.Card(card, "Portrait", Palette.Hex("#0A3D8F"), Palette.Edge, 18);
            var mask = UI.Rect("Mask", pf.rectTransform); UI.Stretch(mask, 4, 4, 4, 4); mask.gameObject.AddComponent<RectMask2D>();
            portrait = UI.Rect("Img", mask).gameObject.AddComponent<RawImage>(); UI.Stretch(portrait.rectTransform);
            placeholder = UI.Text(mask, "<b>SUNI · 수니</b>", 34, Palette.White, TextAlignmentOptions.Center); UI.Stretch(placeholder.rectTransform);
            sweep = UI.Rect("Sweep", mask);
            var si = sweep.gameObject.AddComponent<Image>(); si.color = Palette.Cyan.A(0.35f); si.raycastTarget = false;
            sweep.anchorMin = new Vector2(0, 1); sweep.anchorMax = new Vector2(1, 1); sweep.sizeDelta = new Vector2(0, 6);
            title = UI.Text(card, "", 34, Palette.CyanSoft, TextAlignmentOptions.TopLeft, true, "Title");
            text = UI.Text(card, "", 24, Palette.White, TextAlignmentOptions.TopLeft, false, "Text");
            text.lineSpacing = 12;
            var bg = UI.Panel(card, Palette.Cyan.A(0.15f), 4, "Bar"); bar = bg.rectTransform;
            barFill = UI.Panel(bar, Palette.Cyan, 4, "Fill");
            skip = UI.Button(card, "건너뛰기 ▶", 20, BtnStyle.Ghost, Skip, "Skip");
            root.gameObject.SetActive(false);
        }

        public void Play(ClipKind k, string ttl, string body, Action done)
        {
            kind = k; onDone = done; t = 0; duration = k == ClipKind.Intro ? 6f : 4.5f;
            title.text = ttl; text.text = body;
            root.gameObject.SetActive(true);
            text.ForceMeshUpdate(); textLen = Mathf.Max(text.textInfo.characterCount, body.Length); text.maxVisibleCharacters = 0;
            portrait.texture = app.tutor.PortraitTexture;
            placeholder.gameObject.SetActive(!app.tutor.HasPortrait);
            portrait.uvRect = app.tutor.PortraitUV;
            root.gameObject.SetActive(true);
            root.SetAsLastSibling();
            foreach (var r in rings) r.color = (k == ClipKind.Reward ? Palette.Amber : Palette.Cyan).A(0);
        }

        public void Skip()
        {
            if (!Playing) return;
            root.gameObject.SetActive(false);
            var d = onDone; onDone = null;
            d?.Invoke();
        }

        public void Tick(float dt)
        {
            if (!Playing) return;
            t += dt;
            float p = Mathf.Clamp01(t / duration);
            float s = Mathf.SmoothStep(0.9f, 1f, Mathf.Clamp01(t * 3f));
            card.localScale = new Vector3(s, s, 1);
            text.maxVisibleCharacters = Mathf.Min(textLen, Mathf.FloorToInt(Mathf.Max(0, t - 0.3f) * 60f));
            var mrt = (RectTransform)sweep.parent;
            sweep.anchoredPosition = new Vector2(0, -Mathf.Repeat(t * 0.6f, 1f) * mrt.rect.height);
            barFill.rectTransform.anchorMin = Vector2.zero; barFill.rectTransform.anchorMax = new Vector2(p, 1);
            barFill.rectTransform.offsetMin = barFill.rectTransform.offsetMax = Vector2.zero;
            for (int i = 0; i < rings.Count; i++)
            {
                float rp = Mathf.Repeat(t * 0.45f + i / 3f, 1f);
                float size = Mathf.Lerp(240, 980, rp);
                rings[i].rectTransform.sizeDelta = new Vector2(size, size);
                var col = kind == ClipKind.Reward ? Palette.Amber : Palette.Cyan;
                rings[i].color = col.A((1 - rp) * 0.16f * Mathf.Clamp01(t * 2));
            }
            if (t >= duration) Skip();
        }

        public void Layout(float W, float H)
        {
            float cw = Mathf.Min(W - 40, 820), ch = Mathf.Min(H - 60, W < H ? 640 : 380);
            UI.Place(card, (W - cw) / 2, (H - ch) / 2, cw, ch);
            card.pivot = new Vector2(0.5f, 0.5f);
            card.anchoredPosition = new Vector2(cw / 2 + (W - cw) / 2, -((H - ch) / 2 + ch / 2));
            var pf = (RectTransform)portrait.transform.parent.parent;
            if (W < H)
            {
                float ps = 200;
                UI.Place(pf, (cw - ps) / 2, 28, ps, ps);
                UI.Place(title.rectTransform, 30, 28 + ps + 16, cw - 60, 46);
                UI.Place(text.rectTransform, 30, 28 + ps + 66, cw - 60, ch - ps - 66 - 28 - 90);
            }
            else
            {
                float ps = ch - 120;
                UI.Place(pf, 28, 28, ps, ps);
                float x = 28 + ps + 26;
                UI.Place(title.rectTransform, x, 28, cw - x - 28, 46);
                UI.Place(text.rectTransform, x, 82, cw - x - 28, ch - 82 - 90);
            }
            UI.Place(bar, 28, ch - 40, cw - 28 - 210, 8);
            UI.Place(skip.rt, cw - 28 - 170, ch - 66, 170, 50);
        }
    }
}
