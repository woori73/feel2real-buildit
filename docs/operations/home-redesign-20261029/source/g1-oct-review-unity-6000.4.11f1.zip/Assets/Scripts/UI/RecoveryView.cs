using System;
using System.Linq;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace F2R
{
    public class RecoveryView : DocView
    {
        TMP_InputField field;
        TextMeshProUGUI status;
        string draft;
        public RecoveryView(F2RApp app) : base(app, "RecoveryView") { Rebuild(); app.tutor.SetHint(false); app.tutor.Say("자동 저장이 막힌 환경에서는 복구 텍스트를 따로 보관해 주세요. 다음 접속 때 붙여넣으면 이어서 공부할 수 있어요."); }
        protected override void Rebuild()
        {
            if (field != null) draft = field.text;
            Clear();
            var card = Box(content, "Recovery");
            Heading(card, "학습 기록 내보내기 / 가져오기");
            Para(card, "내보내기를 눌러 복구 텍스트를 만든 뒤 전체를 선택·복사하여 기기의 메모 등에 보관하세요. 가져올 때는 저장한 텍스트를 붙여넣고 확인하세요. 브라우저 저장소가 차단되어도 이번 접속의 기록과 이어하기를 복원할 수 있어요.", 22);
            Para(card, "가져오기는 현재 기록을 교체해요. 먼저 현재 기록을 내보내 두세요. 계정·서버 전송 없이 기기에서만 처리해요.", 19, Palette.Amber);
            var row = Flow(card);
            Action(row, "현재 기록 내보내기", BtnStyle.Primary, () => { field.text = Storage.Export(app.save); draft = field.text; status.text = "복구 텍스트를 만들었어요. 전체 선택 후 복사해 주세요."; });
            Action(row, "전체 선택", BtnStyle.Soft, () => { field.ActivateInputField(); field.Select(); field.MoveTextEnd(false); field.MoveTextStart(true); });
            field = UI.Input(card, "F2R1: 로 시작하는 복구 텍스트", 19);
            field.lineType = TMP_InputField.LineType.MultiLineNewline;
            field.textComponent.richText = false;
            field.characterLimit = 4000000;
            UI.Size(field.gameObject, -1, 330, 1);
            field.text = draft ?? "";
            status = Para(card, "내보낸 텍스트를 잃어버리지 않도록 따로 보관해 주세요.", 20, Palette.CyanSoft);
            var buttons = Flow(card);
            Action(buttons, "이 텍스트로 가져오기", BtnStyle.Soft, ConfirmImport);
            Action(buttons, "홈으로", BtnStyle.Ghost, app.ShowHome);
        }
        void ConfirmImport()
        {
            if (!Storage.TryImport(field.text, app.bank, out var imported, out var error)) { status.text = error; return; }
            app.modal.Show("학습 기록 가져오기", $"복구 텍스트에 {imported.records.Count}개 문항의 학습 기록이 있어요.\n가져오면 현재 기록이 교체돼요.", null,
                ("취소", BtnStyle.Ghost, null),
                ("기록 교체하기", BtnStyle.Primary, () => { app.save = imported; app.sfx.enabled = imported.sfx; app.Persist(); app.ShowHome(); }));
        }
    }
}
