using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

namespace F2R
{
    public enum Result { None = 0, Correct = 1, Wrong = 2, Unanswered = 3, SelfCorrect = 4, SelfWrong = 5 }

    [Serializable]
    public class ItemRecord
    {
        public string id;
        public int attempts;
        public int firstResult;
        public int lastResult;
        public int correctCount;
        public float lastTime;
    }

    [Serializable]
    public class SessionItem
    {
        public string id;
        public int result;
        public string answer = "";
        public float time;
        public bool hintUsed;
        public int points;
        public bool done;
    }

    [Serializable]
    public class SessionState
    {
        public bool active;
        public string mode = "일반";     // 일반 / 오답만 / 전체 다시 / 오답 노트
        public List<SessionItem> items = new List<SessionItem>();
        public int index;
        public int score;
        public int streak;
        public int bestStreak;
        public int timerSec = 90;
    }

    [Serializable]
    public class SaveData
    {
        public int version = 1;
        public List<ItemRecord> records = new List<ItemRecord>();
        public List<string> notebook = new List<string>();
        public SessionState session = new SessionState();
        public SessionState lastResult = new SessionState();
        public int timerSec = 90;
        public int fontStep = 1;
        public bool sfx = true;
        public bool clips = true;
        public int totalXP;
        public int countMode = 1;   // 0: 5, 1: 10, 2: all
        public List<int> selChapters = new List<int>();
        public List<int> selSections = new List<int>();

        public ItemRecord Rec(string id, bool create)
        {
            var r = records.FirstOrDefault(x => x.id == id);
            if (r == null && create) { r = new ItemRecord { id = id }; records.Add(r); }
            return r;
        }
    }

    public static class Storage
    {
        const string Key = "F2R_G1_OCT_REVIEW_v1";
        public static bool Available { get; private set; } = true;

#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")] static extern int F2R_StorageSave(string key, string value);
        [DllImport("__Internal")] static extern string F2R_StorageLoad(string key);
        [DllImport("__Internal")] static extern int F2R_StorageAvailable();
        [DllImport("__Internal")] static extern int F2R_PageActive();
#endif

        public static SaveData Load()
        {
            string json = "";
            try
            {
#if UNITY_WEBGL && !UNITY_EDITOR
                Available = F2R_StorageAvailable() == 1;
                json = Available ? F2R_StorageLoad(Key) : "";
#else
                json = PlayerPrefs.GetString(Key, "");
#endif
            }
            catch (Exception e) { Available = false; Debug.LogWarning("F2R storage load failed: " + e.Message); }
            if (string.IsNullOrEmpty(json)) return new SaveData();
            try { return JsonUtility.FromJson<SaveData>(json) ?? new SaveData(); }
            catch { return new SaveData(); }
        }

        public static void Save(SaveData d)
        {
            try
            {
                string json = JsonUtility.ToJson(d);
#if UNITY_WEBGL && !UNITY_EDITOR
                Available = F2R_StorageSave(Key, json) == 1;
#else
                PlayerPrefs.SetString(Key, json);
                PlayerPrefs.Save();
#endif
            }
            catch (Exception e) { Available = false; Debug.LogWarning("F2R storage save failed: " + e.Message); }
        }

        public static string Export(SaveData data) => "F2R1:" + Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(data)));

        public static bool TryImport(string text, QuestionBank bank, out SaveData data, out string error)
        {
            data = null; error = "올바른 F2R 복구 텍스트를 붙여넣어 주세요.";
            try
            {
                text = text.Trim();
                if (!text.StartsWith("F2R1:") || text.Length > 4000000) return false;
                var bytes = Convert.FromBase64String(text.Substring(5));
                var d = JsonUtility.FromJson<SaveData>(System.Text.Encoding.UTF8.GetString(bytes));
                if (d == null || d.version != 1 || d.records == null || d.notebook == null || d.session == null || d.lastResult == null || d.session.items == null || d.lastResult.items == null || d.selChapters == null || d.selSections == null) return false;
                if (d.records.Any(r => r == null || !bank.byId.ContainsKey(r.id) || r.attempts < 0 || r.firstResult < 0 || r.firstResult > 5 || r.lastResult < 0 || r.lastResult > 5) || d.records.Select(r => r.id).Distinct().Count() != d.records.Count) return false;
                if (d.notebook.Any(id => !bank.byId.ContainsKey(id))) return false;
                foreach (var session in new[] { d.session, d.lastResult })
                {
                    if (session.items.Any(i => i == null || !bank.byId.ContainsKey(i.id) || i.result < 0 || i.result > 5 || float.IsNaN(i.time) || float.IsInfinity(i.time) || i.time < 0) || session.index < 0 || session.index > session.items.Count) return false;
                    if (!F2RApp.TimerOptions.Contains(session.timerSec)) return false;
                }
                if (!F2RApp.TimerOptions.Contains(d.timerSec) || d.totalXP < 0) return false;
                d.fontStep = Mathf.Clamp(d.fontStep, 0, F2RApp.FontSizes.Length - 1);
                d.countMode = Mathf.Clamp(d.countMode, 0, 2);
                data = d; error = ""; return true;
            }
            catch { return false; }
        }

        /// <summary>False while the browser tab is hidden or the page lost focus.</summary>
        public static bool PageActive()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            try { return F2R_PageActive() == 1; } catch { return true; }
#else
            return true;
#endif
        }
    }
}
