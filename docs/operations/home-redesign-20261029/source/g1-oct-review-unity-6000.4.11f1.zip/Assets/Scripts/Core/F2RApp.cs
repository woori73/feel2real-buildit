using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace F2R
{
    public abstract class View
    {
        public RectTransform root;
        protected F2RApp app;
        protected View(F2RApp app, string name) { this.app = app; root = UI.Rect(name, app.mainArea); UI.Stretch(root); }
        public virtual void Layout(float w, float h, bool portrait) { }
        public virtual void Tick(float dt) { }
        public virtual void OnKey(Key k) { }
        public virtual void OnHint() { app.tutor.Say(TutorLines.HomeTip()); }
        public virtual void Destroy() { UnityEngine.Object.Destroy(root.gameObject); }
    }

    /// <summary>Entry point. Builds the whole UI procedurally and owns save data and the current session.</summary>
    public class F2RApp : MonoBehaviour
    {
        public static F2RApp Instance;
        #if UNITY_EDITOR
        public static bool IgnoreFocus = true;
#else
        public static bool IgnoreFocus = false;
#endif

        public QuestionBank bank;
        public SaveData save;
        public Sfx sfx;
        public Canvas canvas;
        CanvasScaler scaler;
        public RectTransform canvasRt, mainArea, overlay;
        public TutorPanel tutor;
        public View view;
        public Modal modal;
        public Clip clip;
        public TopBar top;
        public Vector2 size;
        public bool portrait, mobile;
        Vector2Int lastScreen;
        /// <summary>Editor-only testing aid: lay out for this pixel size instead of the real screen.</summary>
        public static Vector2Int DebugScreen;
        public static bool DebugMobile;
        static int ScreenW => DebugScreen.x > 0 ? DebugScreen.x : Screen.width;
        static int ScreenH => DebugScreen.y > 0 ? DebugScreen.y : Screen.height;
        RawImage grid;
        readonly List<(Image img, float phase, float speed)> sparks = new List<(Image, float, float)>();
        bool wasActive = true;

        public static readonly int[] FontSizes = { 26, 30, 35, 41 };
        public static readonly int[] TimerOptions = { 30, 60, 90, 120, 0 };
        public int PassageFont => FontSizes[Mathf.Clamp(save.fontStep, 0, FontSizes.Length - 1)] + (portrait ? 7 : 0);
        public SessionState Session => save.session;
        public bool Paused => modal.IsOpen || clip.Playing || !PageActive;
        public bool PageActive => IgnoreFocus || (Application.isFocused && Storage.PageActive());

        void Awake()
        {
            Instance = this;
            Application.targetFrameRate = 60;
            UI.Font = Resources.Load<TMP_FontAsset>("Fonts/IBMPlexSansKR-Regular SDF");
            if (UI.Font == null) UI.Font = TMP_Settings.defaultFontAsset;
            // The worksheet uses U+2010. Reuse this font's hyphen glyph without changing source text.
            foreach (var font in new[] { UI.Font, Resources.Load<TMP_FontAsset>("Fonts/IBMPlexSansKR-Bold SDF") })
            {
                if (font == null) continue;
                font.TryAddCharacters("-");
                if (!font.characterLookupTable.ContainsKey(0x2010) && font.characterLookupTable.TryGetValue(45, out var hyphen))
                {
                    font.characterTable.Add(new TMP_Character(0x2010, font, hyphen.glyph));
                    font.ReadFontAssetDefinition();
                }
            }
            bank = QuestionBank.Load();
            foreach (var p in bank.problems) Debug.Log("[F2R data] " + p);
            Debug.Log($"[F2R] Loaded {bank.chapters.Count} chapter(s), {bank.Count} subquestions.");
            save = Storage.Load();
            if (save.session != null && save.session.active && save.session.items.Any(i => !bank.byId.ContainsKey(i.id)))
                save.session.items.RemoveAll(i => !bank.byId.ContainsKey(i.id));
            sfx = new Sfx(gameObject) { enabled = save.sfx };
            UI.OnSound = s => sfx.Play(s);
            BuildRoot();
            ShowHome();
        }

        void BuildRoot()
        {
            if (FindAnyObjectByType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
                es.transform.SetParent(transform);
            }
            var cgo = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            cgo.transform.SetParent(transform, false);
            cgo.layer = 5;
            canvas = cgo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            scaler = cgo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            canvasRt = (RectTransform)cgo.transform;

            // Animated background lives in its own nested canvas so it never forces the main UI to rebatch.
            var bgLayer = UI.Rect("BackgroundLayer", canvasRt); UI.Stretch(bgLayer);
            bgLayer.gameObject.AddComponent<Canvas>();
            var bg = UI.Rect("Background", bgLayer); UI.Stretch(bg);
            var bgi = bg.gameObject.AddComponent<RawImage>(); bgi.texture = Art.Background(); bgi.raycastTarget = false;
            var gr = UI.Rect("Grid", bgLayer); UI.Stretch(gr);
            grid = gr.gameObject.AddComponent<RawImage>(); grid.texture = Art.Grid(); grid.raycastTarget = false;
            var rnd = new System.Random(7);
            for (int i = 0; i < 26; i++)
            {
                var s = UI.Rect("Spark", bgLayer);
                var img = s.gameObject.AddComponent<Image>(); img.sprite = Art.Round; img.type = Image.Type.Sliced; img.pixelsPerUnitMultiplier = 10; img.raycastTarget = false;
                img.color = Palette.Cyan.A(0.4f);
                float sz = 4 + (float)rnd.NextDouble() * 6;
                s.anchorMin = s.anchorMax = new Vector2((float)rnd.NextDouble(), (float)rnd.NextDouble());
                s.sizeDelta = new Vector2(sz, sz);
                sparks.Add((img, (float)rnd.NextDouble() * 6.28f, 0.4f + (float)rnd.NextDouble()));
            }

            top = new TopBar(this, canvasRt);
            mainArea = UI.Rect("Main", canvasRt);
            tutor = new TutorPanel(canvasRt);
            tutor.onHint = () => view?.OnHint();
            overlay = UI.Rect("Overlay", canvasRt); UI.Stretch(overlay);
            modal = new Modal(this, overlay);
            clip = new Clip(this, overlay);
            Relayout(true);
        }

        public void Relayout(bool force = false)
        {
            var scr = new Vector2Int(ScreenW, ScreenH);
            if (!force && scr == lastScreen) return;
            lastScreen = scr;
            float aspect = ScreenW / (float)Mathf.Max(1, ScreenH);
            mobile = Application.isMobilePlatform || DebugMobile;
            portrait = aspect < 1.0f;
            if (portrait)
            {
                scaler.referenceResolution = new Vector2(900, 1600); scaler.matchWidthOrHeight = 0;
                size = new Vector2(900, 900 / aspect);
            }
            else
            {
                float refH = mobile ? 740 : 900;
                if (!mobile && aspect < 1.3f) refH = 1000;
                scaler.referenceResolution = new Vector2(refH * 16f / 9f, refH); scaler.matchWidthOrHeight = 1;
                size = new Vector2(refH * aspect, refH);
            }
            grid.uvRect = new Rect(0, 0, size.x / 96f, size.y / 96f);
            float W = size.x, H = size.y, pad = portrait ? 14 : 18;
            float topH = portrait ? 76 : (mobile ? 62 : 70);
            top.Layout(W, topH, portrait);
            if (portrait)
            {
                float stripH = 176;
                UI.Place(tutor.root, pad, topH + 8, W - 2 * pad, stripH);
                tutor.Layout(W - 2 * pad, stripH, true);
                float y = topH + 8 + stripH + 10;
                UI.Place(mainArea, pad, y, W - 2 * pad, H - y - pad);
            }
            else
            {
                float tw = Mathf.Clamp(W * 0.23f, 270, 380);
                float y = topH + 10;
                UI.Place(tutor.root, W - pad - tw, y, tw, H - y - pad);
                tutor.Layout(tw, H - y - pad, false);
                UI.Place(mainArea, pad, y, W - tw - 3 * pad, H - y - pad);
            }
            modal.Layout(W, H);
            clip.Layout(W, H);
            view?.Layout(mainArea.sizeDelta.x, mainArea.sizeDelta.y, portrait);
        }

        public void SetView(View v)
        {
            view?.Destroy();
            view = v;
            Relayout(true);
        }

        void Update()
        {
            // Clamp so a long hitch (e.g. window resize) can't eat many seconds of a question timer at once.
            float dt = Mathf.Min(Time.unscaledDeltaTime, 0.5f);
            Relayout();
            float t = Time.unscaledTime;
            foreach (var s in sparks)
            {
                s.img.color = Palette.Cyan.A(0.12f + 0.3f * (0.5f + 0.5f * Mathf.Sin(t * s.speed + s.phase)));
            }
            grid.uvRect = new Rect(0, -t * 0.02f, grid.uvRect.width, grid.uvRect.height);

            bool active = PageActive;
            if (wasActive && !active) view?.OnKey(Key.Pause);
            wasActive = active;

            tutor.Tick(dt);
            clip.Tick(dt);
            view?.Tick(dt);
            HandleKeys();
        }

        void HandleKeys()
        {
            var kb = Keyboard.current;
            if (kb == null) return;
            var sel = EventSystem.current != null ? EventSystem.current.currentSelectedGameObject : null;
            bool typing = sel != null && sel.GetComponent<TMP_InputField>() is TMP_InputField f && f.isFocused;
            if (clip.Playing) { if (kb.escapeKey.wasPressedThisFrame || kb.enterKey.wasPressedThisFrame || kb.spaceKey.wasPressedThisFrame) clip.Skip(); return; }
            if (modal.IsOpen) { modal.OnKey(kb); return; }
            foreach (var k in Keys)
            {
                if (!kb[k].wasPressedThisFrame) continue;
                if (typing && k != Key.Enter && k != Key.NumpadEnter && k != Key.Escape) continue;
                view?.OnKey(k);
            }
        }

        static readonly Key[] Keys = { Key.Digit1, Key.Digit2, Key.Digit3, Key.Digit4, Key.Digit5, Key.Digit6, Key.Digit7, Key.Digit8, Key.Digit9, Key.Digit0,
                Key.Numpad1, Key.Numpad2, Key.Numpad3, Key.Numpad4, Key.Numpad5, Key.Numpad6, Key.Numpad7, Key.Numpad8, Key.Numpad9,
                Key.Enter, Key.NumpadEnter, Key.H, Key.Backspace, Key.Escape, Key.UpArrow, Key.DownArrow, Key.PageUp, Key.PageDown, Key.T, Key.F };

        // ---------- Screens ----------
        public void ShowHome() { top.SetMode(TopMode.Home); SetView(new HomeView(this)); }
        public void ShowResults() { top.SetMode(TopMode.Home); SetView(new ResultsView(this)); }
        public void ShowNotebook() { top.SetMode(TopMode.Home); SetView(new NotebookView(this)); }

        // ---------- Session ----------
        public List<Question> Pool(IEnumerable<int> chapters, IEnumerable<Section> sections)
        {
            var cs = chapters.ToList(); var ss = sections.ToList();
            return bank.chapters.Where(c => cs.Count == 0 || cs.Contains(c.number)).SelectMany(c => c.questions)
                .Where(q => ss.Count == 0 || ss.Contains(q.section)).OrderBy(q => q.order).ToList();
        }

        public Result LastResult(string id) { var r = save.Rec(id, false); return r == null ? Result.None : (Result)r.lastResult; }

        /// <summary>Picks n questions: never-tried first, then previously missed, then the rest; keeps source order.</summary>
        public List<Question> PickForSession(List<Question> pool, int n)
        {
            if (n <= 0 || n >= pool.Count) return pool;
            int Rank(Question q)
            {
                var r = LastResult(q.id);
                return r == Result.None ? 0 : (r == Result.Correct || r == Result.SelfCorrect) ? 2 : 1;
            }
            return pool.OrderBy(Rank).ThenBy(q => q.order).Take(n).OrderBy(q => q.order).ToList();
        }

        public void StartSession(List<Question> qs, string mode)
        {
            if (qs.Count == 0) return;
            save.session = new SessionState { active = true, mode = mode, timerSec = save.timerSec, items = qs.Select(q => new SessionItem { id = q.id }).ToList() };
            Persist();
            BeginQuiz(true);
        }

        public void ResumeSession()
        {
            if (!Session.active || Session.items.Count == 0) { ShowHome(); return; }
            Session.index = Session.items.FindIndex(i => !i.done);
            if (Session.index < 0) { FinishSession(); return; }
            BeginQuiz(false);
        }

        void BeginQuiz(bool intro)
        {
            top.SetMode(TopMode.Quiz);
            var quiz = new QuizView(this);
            SetView(quiz);
            if (intro && save.clips)
            {
                var chs = Session.items.Select(i => bank.byId[i.id].chapter).Distinct().Select(c => c + "번");
                string limit = Session.timerSec > 0 ? $"문제당 {Session.timerSec}초" : "시간 제한 없음";
                clip.Play(ClipKind.Intro, "미션 브리핑", $"안녕하세요, 수니예요!\n오늘의 복습 미션: <color=#8BEAFF>{string.Join(", ", chs)}</color> · {Session.items.Count}문항 · {limit}\n타이머는 문제가 준비된 뒤에 시작돼요. 해설을 볼 때는 멈춰요.", () => quiz.ShowCurrent());
            }
            else quiz.ShowCurrent();
        }

        public int Record(Question q, Result r, string answer, float time, bool hint)
        {
            var s = Session;
            var it = s.items[s.index];
            it.result = (int)r; it.answer = answer; it.time = time; it.hintUsed = hint; it.done = true;
            int pts = 0;
            if (r == Result.Correct)
            {
                s.streak++;
                pts = 100;
                // Streak bonus only for answers that took real reading time, so rapid guessing earns nothing extra.
                if (s.streak >= 2 && time >= 4f) pts += 20 * Mathf.Min(s.streak - 1, 5);
            }
            else if (r == Result.SelfCorrect) pts = 50;
            else s.streak = 0;
            s.bestStreak = Mathf.Max(s.bestStreak, s.streak);
            it.points = pts;
            s.score += pts;
            save.totalXP += pts;

            var rec = save.Rec(q.id, true);
            rec.attempts++;
            if (rec.firstResult == 0) rec.firstResult = (int)r;
            rec.lastResult = (int)r;
            rec.lastTime = time;
            bool good = r == Result.Correct || r == Result.SelfCorrect;
            if (good) { rec.correctCount++; save.notebook.Remove(q.id); }
            else if (!save.notebook.Contains(q.id)) save.notebook.Add(q.id);
            Persist();
            return pts;
        }

        public void Advance(QuizView quiz)
        {
            Session.index++;
            if (Session.index >= Session.items.Count) { FinishSession(); return; }
            Persist();
            quiz.ShowCurrent();
        }

        public void FinishSession()
        {
            Session.active = false;
            save.lastResult = JsonUtility.FromJson<SessionState>(JsonUtility.ToJson(Session));
            Persist();
            ShowResults();
            if (save.clips)
            {
                int n = save.lastResult.items.Count;
                int ok = save.lastResult.items.Count(i => i.result == (int)Result.Correct || i.result == (int)Result.SelfCorrect);
                clip.Play(ClipKind.Reward, "미션 완료!", $"{n}문항 중 {ok}문항 정답 · <color=#FFC24B>+{save.lastResult.score} XP</color>\n{TutorLines.Finish(n == 0 ? 0 : ok / (float)n)}", null);
                sfx.Play("reward");
            }
        }

        public void ExitToHome()
        {
            Persist();
            ShowHome();
        }

        public void Persist() => Storage.Save(save);

        public void ResetAll()
        {
            var keep = new SaveData { timerSec = save.timerSec, fontStep = save.fontStep, sfx = save.sfx, clips = save.clips };
            save = keep;
            Persist();
            ShowHome();
        }

        void OnApplicationFocus(bool focus) { if (!focus && !IgnoreFocus) view?.OnKey(Key.Pause); }
    }

    public enum TopMode { Home, Quiz }

    public class TopBar
    {
        readonly F2RApp app;
        public RectTransform root;
        RectTransform logoRt, brandRt, titleRt, progBgRt, xpRt, countRt;
        Image progFill;
        TextMeshProUGUI title, count, xp;
        Btn homeBtn, soundBtn;
        TopMode mode;

        public TopBar(F2RApp app, Transform parent)
        {
            this.app = app;
            var bar = UI.Panel(parent, Palette.Hex("#071640E6"), 0, "TopBar");
            root = bar.rectTransform;
            var line = UI.Rect("Line", root); line.anchorMin = new Vector2(0, 0); line.anchorMax = new Vector2(1, 0); line.pivot = new Vector2(0.5f, 0); line.sizeDelta = new Vector2(0, 2);
            var li = line.gameObject.AddComponent<Image>(); li.color = Palette.Edge.A(0.45f); li.raycastTarget = false;

            var badge = UI.Panel(root, Palette.White, 12, "LogoBadge");
            logoRt = badge.rectTransform;
            var logoTex = Resources.Load<Texture2D>("Media/F2R_logo");
            var logo = UI.Rect("Logo", logoRt); UI.Stretch(logo, 5, 5, 5, 5);
            if (logoTex != null) { var ri = logo.gameObject.AddComponent<RawImage>(); ri.texture = logoTex; ri.raycastTarget = false; }
            else { var t = UI.Text(logo, "F2R", 20, Palette.Navy, TextAlignmentOptions.Center, true); UI.Stretch(t.rectTransform); }
            var brand = UI.Text(root, "<b>F2R</b>", 27, Palette.White, TextAlignmentOptions.MidlineLeft, false, "Brand");
            brand.lineSpacing = -28;
            brandRt = brand.rectTransform;
            title = UI.Text(root, "", 22, Palette.White, TextAlignmentOptions.MidlineLeft, false, "Title");
            title.textWrappingMode = TextWrappingModes.NoWrap; title.overflowMode = TextOverflowModes.Ellipsis;
            titleRt = title.rectTransform;
            var pbg = UI.Panel(root, Palette.Cyan.A(0.15f), 7, "ProgressBg");
            progBgRt = pbg.rectTransform;
            UI.Outline(progBgRt, Palette.Edge.A(0.5f), 7);
            progFill = UI.Panel(progBgRt, Palette.Cyan, 7, "Fill");
            UI.Glow(progFill.rectTransform, Palette.Cyan.A(0.4f), 8);
            count = UI.Text(root, "", 22, Palette.White, TextAlignmentOptions.MidlineLeft, true, "Count");
            countRt = count.rectTransform;
            xp = UI.Text(root, "", 20, Palette.Amber, TextAlignmentOptions.MidlineRight, true, "XP");
            xpRt = xp.rectTransform;
            soundBtn = UI.Button(root, "", 18, BtnStyle.Chip, () =>
            {
                app.save.sfx = !app.save.sfx; app.sfx.enabled = app.save.sfx; app.Persist(); Refresh();
            }, "Sound");
            homeBtn = UI.Button(root, "홈", 19, BtnStyle.Chip, () => (app.view as QuizView)?.AskExit(), "Home");
        }

        public void SetMode(TopMode m) { mode = m; Refresh(); }

        public void Refresh()
        {
            bool quiz = mode == TopMode.Quiz && app.Session.active;
            title.gameObject.SetActive(!quiz);
            progBgRt.gameObject.SetActive(quiz);
            countRt.gameObject.SetActive(quiz);
            homeBtn.go.SetActive(quiz);
            title.text = "고1 10월 영어 복습";
            soundBtn.SetLabel(app.save.sfx ? "소리 켜짐" : "소리 꺼짐");
            int xpVal = quiz ? app.Session.score : app.save.totalXP;
            xp.text = quiz ? $"+{xpVal} XP" : $"누적 {xpVal} XP";
            if (quiz)
            {
                var s = app.Session;
                int n = s.items.Count, done = s.items.Count(i => i.done);
                count.text = $"{Mathf.Min(s.index + 1, n)} / {n}";
                progFill.rectTransform.anchorMin = Vector2.zero;
                progFill.rectTransform.anchorMax = new Vector2(n == 0 ? 0 : Mathf.Max(0.02f, done / (float)n), 1);
                progFill.rectTransform.offsetMin = progFill.rectTransform.offsetMax = Vector2.zero;
            }
        }

        public void Layout(float W, float H, bool portrait)
        {
            UI.Place(root, 0, 0, W, H);
            float pad = portrait ? 14 : 22, ls = H - 18;
            UI.Place(logoRt, pad, 9, ls, ls);
            UI.Place(brandRt, pad + ls + 10, 6, 130, H - 12);
            float right = W - pad;
            float sw = 118, hw = 72;
            UI.Place(soundBtn.rt, right - sw, (H - 42) / 2, sw, 42); right -= sw + 10;
            UI.Place(homeBtn.rt, right - hw, (H - 42) / 2, hw, 42);
            float xr = right - (mode == TopMode.Quiz ? hw + 10 : 0);
            float xw = portrait ? 150 : 170;
            UI.Place(xpRt, xr - xw, 0, xw, H);
            float x0 = pad + ls + 10 + (portrait ? 110 : 130);
            float x1 = xr - xw - 14;
            UI.Place(titleRt, x0, 0, Mathf.Max(50, x1 - x0), H);
            float cw = 92;
            UI.Place(progBgRt, x0, H / 2 - 7, Mathf.Max(50, x1 - x0 - cw - 12), 14);
            UI.Place(countRt, x1 - cw, 0, cw, H);
            Refresh();
        }
    }
}
