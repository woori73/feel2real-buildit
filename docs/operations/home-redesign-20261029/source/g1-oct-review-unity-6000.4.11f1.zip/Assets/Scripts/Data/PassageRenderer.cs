using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace F2R
{
    /// <summary>Builds TextMeshPro rich text for passages, given sentences and feedback.</summary>
    public static class PassageRenderer
    {
        const string Cyan = "#0891B2", Dim = "#7A88A8", Green = "#047857", Red = "#D9465F";
        const string MarkCyan = "#22D3EE80", MarkGreen = "#2BD99B70", MarkRed = "#FF6B8866";

        public static string Esc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.Replace("\u00AD", "");
            return s.IndexOf('<') >= 0 ? "<noparse>" + s + "</noparse>" : s;
        }

        public static string Render(Question q, List<Seg> segs, int selected, bool revealed)
        {
            if (segs == null) return "";
            var sb = new StringBuilder();
            foreach (var s in segs)
            {
                switch (s.type)
                {
                    case SegType.Text: sb.Append(Esc(s.text)); break;
                    case SegType.Bracket: sb.Append(Bracket(q, s, selected, revealed)); break;
                    case SegType.Marker: sb.Append(Marker(q, s, selected, revealed)); break;
                    case SegType.Focus:
                        bool on = q.focus == s.text;
                        sb.Append(on ? $"<link=\"tgt\"><mark={MarkCyan}><b><u>{Esc(s.text)}</u></b></mark></link>" : $"<u>{Esc(s.text)}</u>");
                        break;
                }
            }
            return sb.ToString();
        }

        static string Bracket(Question q, Seg s, int selected, bool revealed)
        {
            if (s != q.target) return $"<color={Dim}>[{Esc(s.text)}]</color>";
            if (!revealed)
            {
                var parts = s.options.Select((o, i) => i == selected ? $"<u>{Esc(o)}</u>" : Esc(o));
                return $"<link=\"tgt\"><mark={MarkCyan}><b><color=#0B4F9C>[{string.Join(" / ", parts)}]</color></b></mark></link>";
            }
            string wrong = selected >= 0 && selected != q.correctIndex ? $"<color={Red}><s>{Esc(s.options[selected])}</s></color> " : "";
            return $"<link=\"tgt\">{wrong}<mark={MarkGreen}><b><color={Green}>{Esc(s.answer)}</color></b></mark></link>";
        }

        static string Marker(Question q, Seg s, int selected, bool revealed)
        {
            string num = Circled.Of(s.number);
            int idx = q.optionMarkers != null ? q.optionMarkers.IndexOf(s) : -1;
            if (q.kind == QKind.Insert && idx >= 0)
            {
                string mark = null;
                if (revealed && idx == q.correctIndex) mark = MarkGreen;
                else if (revealed && idx == selected) mark = MarkRed;
                else if (!revealed && idx == selected) mark = MarkCyan;
                string core = $"<link=\"opt{idx}\"><b><color={Cyan}>{num}</color></b></link>";
                if (mark != null) core = $"<mark={mark}>{core}</mark>";
                if (revealed && idx == q.correctIndex)
                    core += $" <color={Green}><b>{Esc(PlainBox(q))}</b></color>";
                return core;
            }
            if (q.kind == QKind.PickNumber && idx >= 0)
            {
                if (revealed && idx == q.correctIndex)
                    return $"<link=\"opt{idx}\"><mark={MarkGreen}><b><color={Green}>{num}</color></b><s>{Esc(s.text)}</s> <b><color={Green}>{Esc(s.answer)}</color></b></mark></link>";
                string m = revealed && idx == selected ? MarkRed : !revealed && idx == selected ? MarkCyan : null;
                string core = $"<link=\"opt{idx}\"><b><color={Cyan}>{num}</color></b><u>{Esc(s.text)}</u></link>";
                return m != null ? $"<mark={m}>{core}</mark>" : core;
            }
            if ((q.kind == QKind.Short || q.kind == QKind.Descriptive) && s == q.target)
            {
                string content = revealed && s.answer != null ? s.answer : s.text;
                return $"<link=\"tgt\"><mark={(revealed ? MarkGreen : MarkCyan)}><b>{num} {Esc(content)}</b></mark></link>";
            }
            if (q.kind == QKind.Judge)
            {
                if (s != q.target) return $"<color={Dim}><b>{num}</b></color><u>{Esc(s.text)}</u>";
                if (!revealed) return $"<link=\"tgt\"><mark={MarkCyan}><b><color=#0B4F9C>{num}</color></b><u><b>{Esc(s.text)}</b></u></mark></link>";
                if (s.answer != null)
                    return $"<link=\"tgt\"><mark={MarkGreen}><b><color={Green}>{num}</color></b><color={Red}><s>{Esc(s.text)}</s></color> <b><color={Green}>{Esc(s.answer)}</color></b></mark></link>";
                return $"<link=\"tgt\"><mark={MarkGreen}><b><color={Green}>{num}</color></b><u><b>{Esc(s.text)}</b></u> <color={Green}>(O)</color></mark></link>";
            }
            return $"<b>{num}</b>{Esc(s.text)}";
        }

        public static string RenderOrder(Question q, bool revealed)
        {
            var sb = new StringBuilder();
            sb.Append(Esc(q.orderIntro));
            IEnumerable<int> idxs = revealed && q.correctOrder != null && !q.correctOrder.Contains(-1) ? q.correctOrder : Enumerable.Range(0, q.orderParas.Count);
            foreach (var i in idxs)
            {
                var p = q.orderParas[i];
                string col = revealed ? Green : Cyan;
                sb.Append($"\n<b><color={col}>({p.Key})</color></b> ").Append(Esc(p.Value));
            }
            return sb.ToString();
        }

        public static string PlainBox(Question q) => q.box == null ? "" : string.Concat(q.box.Select(s => s.type == SegType.Marker ? Circled.Of(s.number) + s.text : s.type == SegType.Bracket ? "[" + s.text + "]" : s.text));

        /// <summary>The sentence containing the target, with the correct answer applied (for feedback).</summary>
        public static string CorrectSentence(Question q)
        {
            switch (q.kind)
            {
                case QKind.Choice:
                    if (q.target == null) return null;
                    bool inBox = q.box != null && q.box.Contains(q.target);
                    return Sentence(inBox ? q.box : q.passage, q.target, !inBox);
                case QKind.Short:
                    return q.target == null ? null : Sentence(q.passage, q.target, true);
                case QKind.Judge:
                case QKind.PickNumber:
                    var t = q.kind == QKind.Judge ? q.target : (q.correctIndex >= 0 ? q.optionMarkers[q.correctIndex] : null);
                    return t == null ? null : Sentence(q.passage, t, true);
                case QKind.Insert:
                    if (q.correctIndex < 0) return null;
                    return InsertContext(q);
            }
            return null;
        }

        static string Resolve(Seg s)
        {
            switch (s.type)
            {
                case SegType.Bracket: return s.answer ?? s.options[0];
                case SegType.Marker: return s.answer ?? s.text;
                default: return s.text;
            }
        }

        static string Sentence(List<Seg> segs, Seg target, bool cut)
        {
            var sb = new StringBuilder();
            int start = 0, end = 0;
            foreach (var s in segs)
            {
                if (s == target) start = sb.Length;
                sb.Append(Resolve(s).Replace("\u00AD", ""));
                if (s == target) end = sb.Length;
            }
            string text = sb.ToString();
            int a = 0, b = text.Length;
            if (cut)
            {
                for (int i = start - 1; i > 0; i--)
                    if ((text[i] == ' ' || text[i] == '\n') && ".?!".IndexOf(text[i - 1]) >= 0) { a = i + 1; break; }
                for (int i = end; i < text.Length; i++)
                    if (".?!".IndexOf(text[i]) >= 0 && (i + 1 == text.Length || text[i + 1] == ' ' || text[i + 1] == '\n')) { b = i + 1; break; }
            }
            start = System.Math.Max(start, a); end = System.Math.Min(end, b);
            return Esc(text.Substring(a, start - a).TrimStart()) + $"<b><color=#2BD99B>{Esc(text.Substring(start, end - start))}</color></b>" + Esc(text.Substring(end, b - end).TrimEnd());
        }

        static string InsertContext(Question q)
        {
            var target = q.optionMarkers[q.correctIndex];
            var before = new StringBuilder();
            var after = new StringBuilder();
            bool past = false;
            foreach (var s in q.passage)
            {
                if (s == target) { past = true; continue; }
                if (s.type == SegType.Marker) continue;
                (past ? after : before).Append(Resolve(s));
            }
            string b = before.ToString().Replace("\u00AD", "").TrimEnd();
            string a = after.ToString().Replace("\u00AD", "").TrimStart();
            int cut = System.Math.Max(b.LastIndexOf(". ", System.StringComparison.Ordinal), System.Math.Max(b.LastIndexOf("? ", System.StringComparison.Ordinal), b.LastIndexOf("! ", System.StringComparison.Ordinal)));
            string prev = cut >= 0 ? b.Substring(cut + 2) : b;
            int e = a.IndexOf(". ", System.StringComparison.Ordinal);
            string next = e >= 0 ? a.Substring(0, e + 1) : a;
            return $"{Esc(prev.Trim())} <b><color=#2BD99B>{Esc(PlainBox(q).Trim())}</color></b> {Esc(next)}";
        }
    }
}
