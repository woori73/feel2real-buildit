using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;

namespace F2R
{
    public enum QKind { Choice, Order, Insert, PickNumber, Judge, TrueFalse, Short, Descriptive }
    public enum Section { Choice, Order, Insert, VocabFix, GrammarFix, Writing, Other }

    public enum SegType { Text, Bracket, Marker, Focus }

    /// <summary>One piece of a passage: plain text, a [a / b] bracket, a circled marker or an underlined focus word.</summary>
    public class Seg
    {
        public SegType type;
        public string text;      // Text: content. Bracket: inner "a / b". Marker: target words after it. Focus: "(A)that".
        public int number;       // Marker: 1-based circled number
        public List<string> options;   // Bracket options
        public string answer;          // Bracket: correct option. Marker (grammar fix): correction or null.
    }

    public class Question
    {
        public string id, sourceId, groupId, sourceNotice;
        public int chapter;
        public Section section;
        public string sectionTitle;
        public QKind kind;
        public string prompt;
        public List<Seg> passage;
        public List<Seg> box;           // given sentence / summary sentence / statement
        public string boxLabel;
        public Seg target;              // highlighted bracket or marker
        public string focus;            // focus word to highlight ("(A)that")
        public List<string> options = new List<string>();
        public List<Seg> optionMarkers; // Insert / PickNumber: marker seg per option
        public int correctIndex = -1;
        public List<int> correctOrder;  // Order
        public string orderIntro;
        public List<KeyValuePair<string, string>> orderParas; // label, text
        public string answerDisplay;
        public string modelAnswer;
        public List<string> accepted = new List<string>();
        public string hint, explanation;
        public List<string> vocab = new List<string>();
        public int order;               // global source order

        public bool IsSelfAssessed => kind == QKind.Descriptive;
    }

    public class Chapter
    {
        public int number;
        public string title = "";
        public string summary = "";
        public List<string> vocab = new List<string>();
        public List<Question> questions = new List<Question>();
    }

    public static class Circled
    {
        public const string All = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳";
        public static string Of(int n) => n >= 1 && n <= 20 ? All[n - 1].ToString() : n.ToString();
        public static int Parse(char c) { int i = All.IndexOf(c); return i < 0 ? -1 : i + 1; }
        public static bool Is(char c) => All.IndexOf(c) >= 0;
    }

    public static class SectionInfo
    {
        public static readonly Section[] Order = { Section.Choice, Section.Order, Section.Insert, Section.VocabFix, Section.GrammarFix, Section.Writing, Section.Other };
        public static string Name(Section s)
        {
            switch (s)
            {
                case Section.Choice: return "어법·어휘 선택";
                case Section.Order: return "문장 순서";
                case Section.Insert: return "문장 넣기";
                case Section.VocabFix: return "어휘 고치기";
                case Section.GrammarFix: return "어법 고치기";
                case Section.Writing: return "서술형 대비";
                default: return "기타";
            }
        }
        public static Section FromTitle(string title, string body)
        {
            string t = title.Replace(" ", "");
            if (t.Contains("문장넣기") || t.Contains("삽입")) return Section.Insert;
            if (t.Contains("순서")) return Section.Order;
            if (t.Contains("서술형")) return Section.Writing;
            if (t.Contains("어휘틀린") || (t.Contains("어휘") && t.Contains("고치"))) return Section.VocabFix;
            if (t.Contains("어법틀린") || (t.Contains("어법") && t.Contains("고치"))) return Section.GrammarFix;
            if (t.Contains("선택") || body.Contains(" / ")) return Section.Choice;
            return Section.Other;
        }
    }

    /// <summary>Parses the raw worksheet text exactly as supplied. The line right after each "NN-N." heading is the answer key.</summary>
    public static class WorksheetParser
    {
        static readonly Regex Heading = new Regex(@"^(\d{1,2})-(\d+)\.\s*(.*)$");
        static readonly Regex ChapterLine = new Regex(@"^\d{1,2}\.$");
        static readonly Regex SubQ = new Regex(@"^(\d+)\.\s+(.*)$");
        static readonly Regex Token = new Regex(@"\[([^\]]+)\]|[①-⑳]|\(([A-E])\)([A-Za-z’']+)");

        class RawSection { public int chapter, num; public string title; public List<string> lines = new List<string>(); }

        public static List<Question> Parse(string raw, List<string> problems)
        {
            var sections = new List<RawSection>();
            RawSection cur = null;
            foreach (var line in raw.Replace("\r\n", "\n").Split('\n'))
            {
                string t = line.Trim();
                if (t.Length == 0) continue;
                if (t.Contains("모의고사") && t.Contains("복습")) continue;
                if (ChapterLine.IsMatch(t)) continue;
                var m = Heading.Match(t);
                if (m.Success)
                {
                    cur = new RawSection { chapter = int.Parse(m.Groups[1].Value), num = int.Parse(m.Groups[2].Value), title = m.Groups[3].Value.Trim() };
                    sections.Add(cur);
                    continue;
                }
                cur?.lines.Add(t);
            }

            var result = new List<Question>();
            foreach (var s in sections)
            {
                if (s.lines.Count < 2) { problems.Add($"{s.chapter}-{s.num}: 본문 또는 정답 없음"); continue; }
                string src = $"{s.chapter}-{s.num}";
                string key = s.lines[0];
                var body = s.lines.Skip(1).ToList();
                var sec = SectionInfo.FromTitle(s.title, string.Join("\n", body));
                List<Question> qs;
                try
                {
                    switch (sec)
                    {
                        case Section.Choice: qs = ParseChoice(src, key, body, problems); break;
                        case Section.Order: qs = ParseOrder(src, key, body, problems); break;
                        case Section.Insert: qs = ParseInsert(src, key, body, problems); break;
                        case Section.VocabFix: qs = ParseVocabFix(src, key, body, problems); break;
                        case Section.GrammarFix: qs = ParseGrammarFix(src, key, body, problems); break;
                        case Section.Writing: qs = ParseWriting(src, key, body, problems); break;
                        default: qs = new List<Question> { Descriptive(src, src, body.Last(), key, Segment(string.Join("\n", body.Take(body.Count - 1)), false)) }; break;
                    }
                }
                catch (Exception e) { problems.Add($"{src}: 파싱 오류 {e.Message}"); continue; }
                foreach (var q in qs)
                {
                    q.groupId = src; q.sourceId = src; q.chapter = s.chapter; q.section = sec; q.sectionTitle = s.title;
                    result.Add(q);
                }
            }
            return result;
        }

        /// <summary>Splits text into segments. withTargets: markers take the following word as their target.</summary>
        public static List<Seg> Segment(string text, bool withTargets)
        {
            var segs = new List<Seg>();
            int pos = 0;
            foreach (Match m in Token.Matches(text))
            {
                if (m.Index > pos) segs.Add(new Seg { type = SegType.Text, text = text.Substring(pos, m.Index - pos) });
                if (m.Groups[1].Success)
                    segs.Add(new Seg { type = SegType.Bracket, text = m.Groups[1].Value, options = m.Groups[1].Value.Split('/').Select(o => o.Trim()).ToList() });
                else if (m.Groups[2].Success)
                    segs.Add(new Seg { type = SegType.Focus, text = m.Value });
                else
                    segs.Add(new Seg { type = SegType.Marker, number = Circled.Parse(m.Value[0]), text = "" });
                pos = m.Index + m.Length;
            }
            if (pos < text.Length) segs.Add(new Seg { type = SegType.Text, text = text.Substring(pos) });
            if (withTargets)
                for (int i = 0; i < segs.Count - 1; i++)
                    if (segs[i].type == SegType.Marker && segs[i + 1].type == SegType.Text)
                    {
                        var w = Regex.Match(segs[i + 1].text, @"^[A-Za-z0-9’'‐\-]+");
                        if (w.Success) { segs[i].text = w.Value; segs[i + 1].text = segs[i + 1].text.Substring(w.Length); }
                    }
            return segs;
        }

        /// <summary>Extends a marker's target to a longer phrase (e.g. "are based on") taken from the following text.</summary>
        public static void SetMarkerTarget(List<Seg> segs, Seg marker, string target)
        {
            int i = segs.IndexOf(marker);
            if (i < 0 || string.IsNullOrEmpty(target)) return;
            string joined = marker.text + (i + 1 < segs.Count && segs[i + 1].type == SegType.Text ? segs[i + 1].text : "");
            if (!joined.StartsWith(target)) return;
            marker.text = target;
            if (i + 1 < segs.Count && segs[i + 1].type == SegType.Text) segs[i + 1].text = joined.Substring(target.Length);
        }

        static List<Seg> Markers(List<Seg> segs) => segs.Where(x => x.type == SegType.Marker).ToList();

        static List<Question> ParseChoice(string src, string key, List<string> body, List<string> problems)
        {
            var segs = Segment(string.Join("\n", body), false);
            var keys = key.Split('/').Select(k => k.Trim()).ToList();
            var brackets = segs.Where(x => x.type == SegType.Bracket).ToList();
            if (keys.Count != brackets.Count) problems.Add($"{src}: 정답 수({keys.Count})와 괄호 수({brackets.Count}) 불일치");
            var list = new List<Question>();
            for (int i = 0; i < brackets.Count && i < keys.Count; i++)
            {
                var b = brackets[i];
                int ci = b.options.FindIndex(o => string.Equals(o, keys[i], StringComparison.OrdinalIgnoreCase));
                if (ci < 0) { problems.Add($"{src}-{i + 1}: 정답 '{keys[i]}'이 보기에 없음"); continue; }
                b.answer = b.options[ci];
                list.Add(new Question
                {
                    id = $"{src}-{i + 1}", kind = QKind.Choice, passage = segs, target = b,
                    prompt = $"표시된 괄호 [{b.text}] 안에서 어법·문맥상 알맞은 것을 고르세요. ({i + 1}/{brackets.Count})",
                    options = new List<string>(b.options), correctIndex = ci, answerDisplay = b.options[ci]
                });
            }
            return list;
        }

        static List<Question> ParseOrder(string src, string key, List<string> body, List<string> problems)
        {
            var intro = new List<string>();
            var paras = new List<KeyValuePair<string, string>>();
            foreach (var l in body)
            {
                var m = Regex.Match(l, @"^\(([A-E])\)\s*(.*)$");
                if (m.Success) paras.Add(new KeyValuePair<string, string>(m.Groups[1].Value, m.Groups[2].Value));
                else if (paras.Count == 0) intro.Add(l);
                else paras[paras.Count - 1] = new KeyValuePair<string, string>(paras[paras.Count - 1].Key, paras[paras.Count - 1].Value + "\n" + l);
            }
            paras.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));
            var letters = Regex.Matches(key, "[A-E]").Cast<Match>().Select(m => m.Value).ToList();
            var order = letters.Select(l => paras.FindIndex(p => p.Key == l)).ToList();
            if (order.Count != paras.Count || order.Contains(-1)) problems.Add($"{src}: 순서 정답 '{key}' 해석 실패");
            return new List<Question> { new Question {
                id = src, kind = QKind.Order, orderIntro = string.Join("\n", intro), orderParas = paras,
                prompt = "주어진 글 다음에 이어질 글의 순서로 가장 적절한 것을 차례로 누르세요.",
                options = paras.Select(p => $"({p.Key})").ToList(), correctOrder = order,
                answerDisplay = string.Join(" - ", letters.Select(l => $"({l})"))
            } };
        }

        static List<Question> ParseInsert(string src, string key, List<string> body, List<string> problems)
        {
            var given = body[0];
            var segs = Segment(string.Join("\n", body.Skip(1)), false);
            var marks = Markers(segs);
            int ans = key.Length > 0 ? Circled.Parse(key.Trim()[0]) : -1;
            int ci = marks.FindIndex(x => x.number == ans);
            if (ci < 0) problems.Add($"{src}: 정답 위치 '{key}'를 본문에서 찾지 못함");
            return new List<Question> { new Question {
                id = src, kind = QKind.Insert, passage = segs, box = Segment(given, false), boxLabel = "주어진 문장",
                prompt = "글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르세요. (지문의 번호를 눌러도 돼요)",
                options = marks.Select(x => Circled.Of(x.number)).ToList(), optionMarkers = marks, correctIndex = ci,
                answerDisplay = ans > 0 ? Circled.Of(ans) : key
            } };
        }

        static List<Question> ParseVocabFix(string src, string key, List<string> body, List<string> problems)
        {
            var segs = Segment(string.Join("\n", body), true);
            var marks = Markers(segs);
            var k = key.Trim();
            int ans = Circled.Parse(k[0]);
            string correction = k.Substring(1).Trim();
            int ci = marks.FindIndex(x => x.number == ans);
            if (ci < 0) { problems.Add($"{src}: 정답 번호 '{key}' 없음"); }
            else marks[ci].answer = correction;
            string wrong = ci >= 0 ? marks[ci].text : "";
            return new List<Question> { new Question {
                id = src, kind = QKind.PickNumber, passage = segs,
                prompt = "글의 흐름으로 보아, 밑줄 친 낱말의 쓰임이 적절하지 않은 것을 고르세요. (정답 확인 후 고친 낱말이 공개돼요)",
                options = marks.Select(x => $"{Circled.Of(x.number)} {x.text}").ToList(), optionMarkers = marks, correctIndex = ci,
                answerDisplay = $"{Circled.Of(ans)} {wrong} → {correction}"
            } };
        }

        static List<Question> ParseGrammarFix(string src, string key, List<string> body, List<string> problems)
        {
            var segs = Segment(string.Join("\n", body), true);
            var fixes = new Dictionary<int, string>();
            foreach (Match m in Regex.Matches(key, @"([①-⑳])\s*([^①-⑳]*)"))
                fixes[Circled.Parse(m.Groups[1].Value[0])] = m.Groups[2].Value.Trim();
            var list = new List<Question>();
            foreach (var mk in Markers(segs))
            {
                bool wrong = fixes.TryGetValue(mk.number, out var fix);
                mk.answer = wrong ? fix : null;
                list.Add(new Question
                {
                    id = $"{src}-{Circled.Of(mk.number)}", kind = QKind.Judge, passage = segs, target = mk,
                    options = new List<string> { "맞음 (O)", "틀림 (X)" }, correctIndex = wrong ? 1 : 0
                });
            }
            foreach (var n in fixes.Keys) if (!Markers(segs).Any(x => x.number == n)) problems.Add($"{src}: 정답 번호 {Circled.Of(n)}가 본문에 없음");
            return list;
        }

        /// <summary>Called after notes are applied so the prompt shows the final target phrase.</summary>
        public static void FinishJudge(Question q)
        {
            var mk = q.target;
            q.prompt = $"지문의 {Circled.Of(mk.number)} '{mk.text}' — 어법상 올바른 표현인가요?";
            q.answerDisplay = mk.answer != null ? $"틀림 (X) · {mk.text} → {mk.answer}" : "맞음 (O) · 올바른 표현";
        }

        static Question Descriptive(string id, string src, string prompt, string model, List<Seg> passage)
        {
            return new Question { id = id, kind = QKind.Descriptive, passage = passage, prompt = prompt, modelAnswer = model, answerDisplay = model };
        }

        static List<Question> ParseWriting(string src, string key, List<string> body, List<string> problems)
        {
            var passageLines = new List<string>();
            var subs = new List<(int n, string prompt, List<string> extra)>();
            foreach (var l in body)
            {
                var m = SubQ.Match(l);
                if (m.Success) subs.Add((int.Parse(m.Groups[1].Value), l, new List<string>()));
                else if (subs.Count == 0) passageLines.Add(l);
                else subs[subs.Count - 1].extra.Add(l);
            }
            var passage = Segment(string.Join("\n", passageLines), false);
            var keys = new Dictionary<int, string>();
            var km = Regex.Matches(key, @"(?:^|\s)(\d+)\.\s");
            for (int i = 0; i < km.Count; i++)
            {
                int start = km[i].Index + km[i].Length;
                int end = i + 1 < km.Count ? km[i + 1].Index : key.Length;
                keys[int.Parse(km[i].Groups[1].Value)] = key.Substring(start, end - start).Trim();
            }
            var list = new List<Question>();
            foreach (var sq in subs)
            {
                keys.TryGetValue(sq.n, out var k);
                k = k ?? "";
                string sid = $"{src}-{sq.n}";
                bool hasStatements = sq.extra.Count > 0 && sq.extra.All(e => Circled.Is(e[0]));
                if (hasStatements && Regex.IsMatch(k, @"[①-⑳]\s*[TF]\b"))
                {
                    var tf = new Dictionary<int, int>();
                    foreach (Match m in Regex.Matches(k, @"([①-⑳])\s*([TF])")) tf[Circled.Parse(m.Groups[1].Value[0])] = m.Groups[2].Value == "T" ? 0 : 1;
                    foreach (var e in sq.extra)
                    {
                        int n = Circled.Parse(e[0]);
                        if (!tf.TryGetValue(n, out var ans)) { problems.Add($"{sid}-{Circled.Of(n)}: T/F 정답 없음"); continue; }
                        list.Add(new Question
                        {
                            id = $"{sid}-{Circled.Of(n)}", kind = QKind.TrueFalse, passage = passage, prompt = sq.prompt,
                            box = Segment(e, false), boxLabel = "진술문 — 윗글의 내용과 일치하면 T, 일치하지 않으면 F",
                            options = new List<string> { "T (일치)", "F (불일치)" }, correctIndex = ans, answerDisplay = ans == 0 ? "T" : "F"
                        });
                    }
                }
                else if (hasStatements && Regex.IsMatch(k, @"^[①-⑳]$"))
                {
                    var opts = sq.extra.Select(e => e).ToList();
                    list.Add(new Question
                    {
                        id = sid, kind = QKind.Choice, passage = passage, prompt = sq.prompt, options = opts,
                        correctIndex = opts.FindIndex(o => o[0] == k[0]), answerDisplay = opts.FirstOrDefault(o => o[0] == k[0]) ?? k
                    });
                }
                else if (sq.extra.Any(e => e.Contains("[")))
                {
                    var box = Segment(string.Join("\n", sq.extra), false);
                    var ans = new Dictionary<string, string>();
                    foreach (Match m in Regex.Matches(k, @"\(([A-E])\)\s*(.+?)(?=\s*\([A-E]\)|$)")) ans[m.Groups[1].Value] = m.Groups[2].Value.Trim();
                    var plain = new List<string>();
                    int bi = 0;
                    for (int i = 0; i < box.Count; i++)
                    {
                        if (box[i].type != SegType.Bracket) continue;
                        bi++;
                        string letter = null;
                        if (i > 0 && box[i - 1].type == SegType.Text)
                        {
                            var lm = Regex.Match(box[i - 1].text, @"\(([A-E])\)\s*$");
                            if (lm.Success) letter = lm.Groups[1].Value;
                        }
                        string a = letter != null && ans.TryGetValue(letter, out var av) ? av : null;
                        var b = box[i];
                        int ci = a == null ? -1 : b.options.FindIndex(o => string.Equals(o, a, StringComparison.OrdinalIgnoreCase));
                        string qid = letter != null ? $"{sid}-{letter}" : $"{sid}-{bi}";
                        if (ci < 0) { problems.Add($"{qid}: 정답 '{a}' 해석 실패"); continue; }
                        b.answer = b.options[ci];
                        list.Add(new Question
                        {
                            id = qid, kind = QKind.Choice, passage = passage, box = box, boxLabel = "요약문", target = b,
                            prompt = sq.prompt + (letter != null ? $" — ({letter})" : ""),
                            options = new List<string>(b.options), correctIndex = ci, answerDisplay = (letter != null ? $"({letter}) " : "") + b.options[ci]
                        });
                    }
                }
                else
                {
                    bool english = sq.prompt.Contains("영어로") || !Regex.IsMatch(k, "[가-힣]");
                    var q = Descriptive(sid, src, sq.prompt, k, passage);
                    if (english) { q.kind = QKind.Short; q.accepted.Add(k); }
                    if (sq.extra.Count > 0) { q.box = Segment(string.Join("\n", sq.extra), false); q.boxLabel = "제시문"; }
                    list.Add(q);
                }
            }
            return list;
        }
    }

    /// <summary>Hand-written Korean hints/explanations keyed by subquestion ID.</summary>
    public static class NotesParser
    {
        public class Block { public Dictionary<string, string> f = new Dictionary<string, string>(); }

        public static Dictionary<string, Block> Parse(string raw, Chapter ch)
        {
            var blocks = new Dictionary<string, Block>();
            var chapterBlock = new Block();
            Block cur = chapterBlock;
            string lastKey = null;
            foreach (var line0 in raw.Replace("\r\n", "\n").Split('\n'))
            {
                var line = line0.TrimEnd();
                if (line.StartsWith("#chapter")) continue;
                if (line.StartsWith("@")) { cur = new Block(); blocks[line.Substring(1).Trim()] = cur; lastKey = null; continue; }
                var m = Regex.Match(line, @"^([a-z]+):\s?(.*)$");
                if (m.Success) { lastKey = m.Groups[1].Value; cur.f[lastKey] = m.Groups[2].Value; }
                else if (lastKey != null && line.Trim().Length > 0) cur.f[lastKey] += "\n" + line.Trim();
            }
            if (ch != null)
            {
                chapterBlock.f.TryGetValue("title", out ch.title);
                chapterBlock.f.TryGetValue("summary", out ch.summary);
                if (chapterBlock.f.TryGetValue("vocab", out var v)) ch.vocab = SplitVocab(v);
                ch.title = ch.title ?? ""; ch.summary = ch.summary ?? "";
            }
            return blocks;
        }

        public static List<string> SplitVocab(string v) => v.Split('|').Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
    }

    public class QuestionBank
    {
        public List<Chapter> chapters = new List<Chapter>();
        public Dictionary<string, Question> byId = new Dictionary<string, Question>();
        public List<string> problems = new List<string>();
        public int Count => byId.Count;

        public static QuestionBank Load()
        {
            var bank = new QuestionBank();
            var sheets = Resources.LoadAll<TextAsset>("Worksheets").OrderBy(t => t.name).ToList();
            int order = 0;
            foreach (var sheet in sheets)
            {
                var qs = WorksheetParser.Parse(sheet.text, bank.problems);
                foreach (var grp in qs.GroupBy(q => q.chapter))
                {
                    var ch = bank.chapters.FirstOrDefault(c => c.number == grp.Key);
                    if (ch == null) { ch = new Chapter { number = grp.Key }; bank.chapters.Add(ch); }
                    var notes = Resources.Load<TextAsset>($"Notes/ch{grp.Key}");
                    var blocks = notes != null ? NotesParser.Parse(notes.text, ch) : new Dictionary<string, NotesParser.Block>();
                    foreach (var q in grp)
                    {
                        if (bank.byId.ContainsKey(q.id)) { bank.problems.Add($"{q.id}: 중복 ID"); continue; }
                        if (blocks.TryGetValue(q.id, out var b)) Apply(q, b);
                        else bank.problems.Add($"{q.id}: 해설 노트 없음 (자동 해설 사용)");
                        if (q.kind == QKind.Judge) WorksheetParser.FinishJudge(q);
                        q.order = order++;
                        ch.questions.Add(q);
                        bank.byId[q.id] = q;
                    }
                }
            }
            ImportedWorksheets.Append(bank);
            bank.chapters.Sort((a, b) => a.number.CompareTo(b.number));
            return bank;
        }

        static void Apply(Question q, NotesParser.Block b)
        {
            b.f.TryGetValue("hint", out q.hint);
            b.f.TryGetValue("exp", out q.explanation);
            if (b.f.TryGetValue("vocab", out var v)) q.vocab = NotesParser.SplitVocab(v);
            if (b.f.TryGetValue("focus", out var f)) q.focus = f.Trim();
            if (b.f.TryGetValue("accept", out var a)) q.accepted.AddRange(NotesParser.SplitVocab(a));
            if (b.f.TryGetValue("target", out var t) && q.target != null && q.target.type == SegType.Marker)
                WorksheetParser.SetMarkerTarget(q.passage, q.target, t.Trim());
        }

        public Chapter GetChapter(int n) => chapters.FirstOrDefault(c => c.number == n);
    }
}
