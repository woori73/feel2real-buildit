using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace F2R
{
    // Nimble Fox: data is generated locally from the checksum-verified worksheet source.
    public static class ImportedWorksheets
    {
        [Serializable] public class Corpus { public int groups; public string sourceSha256; public ChapterDto[] chapters; public ItemDto[] items; }
        [Serializable] public class ChapterDto { public int number; public string title, summary; public string[] vocab; }
        [Serializable] public class MarkDto { public int number; public string text; }
        [Serializable] public class ParaDto { public string label, text; }
        [Serializable] public class ItemDto
        {
            public string id, sourceId, groupId, sectionTitle, prompt, passage, box, boxLabel, answerDisplay, modelAnswer, hint, explanation, sourceNotice, orderIntro;
            public int chapter, section, kind, correctIndex, targetIndex, targetNumber;
            public bool targetInBox;
            public string[] options, accepted, bracketAnswers, vocab;
            public int[] correctOrder, markerNumbers;
            public MarkDto[] markerTargets, markerFixes;
            public ParaDto[] paras;
        }

        public static void Append(QuestionBank bank)
        {
            var asset = Resources.Load<TextAsset>("WorksheetsImported");
            if (asset == null) return;
            var data = JsonUtility.FromJson<Corpus>(asset.text);
            foreach (var c in data.chapters)
            {
                var ch = bank.GetChapter(c.number);
                if (ch == null) { ch = new Chapter { number = c.number }; bank.chapters.Add(ch); }
                if (c.number != 31) { ch.title = c.title; ch.summary = c.summary; ch.vocab = c.vocab.ToList(); }
            }
            foreach (var d in data.items)
            {
                if (bank.byId.ContainsKey(d.id)) { bank.problems.Add(d.id + ": 중복 ID"); continue; }
                var p = WorksheetParser.Segment(d.passage ?? "", true);
                var box = string.IsNullOrEmpty(d.box) ? null : WorksheetParser.Segment(d.box, false);
                var q = new Question {
                    id = d.id, sourceId = d.sourceId, groupId = d.groupId, chapter = d.chapter,
                    section = (Section)d.section, sectionTitle = d.sectionTitle, kind = (QKind)d.kind,
                    prompt = d.prompt, passage = p, box = box, boxLabel = d.boxLabel,
                    options = (d.options ?? Array.Empty<string>()).ToList(), correctIndex = d.correctIndex,
                    answerDisplay = d.answerDisplay, modelAnswer = d.modelAnswer,
                    accepted = (d.accepted ?? Array.Empty<string>()).ToList(), hint = d.hint,
                    explanation = d.explanation, sourceNotice = d.sourceNotice,
                    vocab = (d.vocab ?? Array.Empty<string>()).ToList(), orderIntro = d.orderIntro,
                    correctOrder = d.correctOrder?.ToList(),
                    orderParas = d.paras?.Select(x => new KeyValuePair<string,string>(x.label, x.text)).ToList()
                };
                if (d.markerTargets != null)
                    foreach (var mk in d.markerTargets)
                    {
                        var s = p.FirstOrDefault(x => x.type == SegType.Marker && x.number == mk.number);
                        if (s != null) WorksheetParser.SetMarkerTarget(p, s, mk.text);
                    }
                if (d.markerFixes != null)
                    foreach (var mk in d.markerFixes)
                    {
                        var s = p.FirstOrDefault(x => x.type == SegType.Marker && x.number == mk.number);
                        if (s != null) s.answer = mk.text;
                    }
                if (d.targetNumber > 0) q.target = p.FirstOrDefault(x => x.type == SegType.Marker && x.number == d.targetNumber);
                var brackets = (d.targetInBox ? box : p)?.Where(x => x.type == SegType.Bracket).ToList();
                if (brackets != null && d.bracketAnswers != null)
                {
                    if (brackets.Count != d.bracketAnswers.Length) bank.problems.Add(d.id + ": 괄호 매핑 불일치");
                    for (int i = 0; i < brackets.Count && i < d.bracketAnswers.Length; i++) brackets[i].answer = d.bracketAnswers[i];
                    if (d.targetIndex >= 0 && d.targetIndex < brackets.Count) q.target = brackets[d.targetIndex];
                }
                if (d.markerNumbers != null)
                    q.optionMarkers = d.markerNumbers.Select(n => p.FirstOrDefault(x => x.type == SegType.Marker && x.number == n)).ToList();
                if (q.kind == QKind.Judge) WorksheetParser.FinishJudge(q);
                bank.GetChapter(d.chapter).questions.Add(q);
                bank.byId.Add(q.id, q);
            }
            bank.chapters.Sort((a,b) => a.number.CompareTo(b.number));
            int order = 0;
            foreach (var ch in bank.chapters) foreach (var q in ch.questions) q.order = order++;
        }
    }
}
