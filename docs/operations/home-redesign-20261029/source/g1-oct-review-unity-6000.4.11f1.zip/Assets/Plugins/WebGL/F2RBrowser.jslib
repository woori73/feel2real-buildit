mergeInto(LibraryManager.library, {
  F2R_StorageSave: function (keyPtr, valuePtr) {
    try {
      window.localStorage.setItem(UTF8ToString(keyPtr), UTF8ToString(valuePtr));
      return 1;
    } catch (e) { return 0; }
  },
  F2R_StorageLoad: function (keyPtr) {
    var value = "";
    try {
      var v = window.localStorage.getItem(UTF8ToString(keyPtr));
      if (v !== null) value = v;
    } catch (e) { value = ""; }
    var size = lengthBytesUTF8(value) + 1;
    var buffer = _malloc(size);
    stringToUTF8(value, buffer, size);
    return buffer;
  },
  F2R_StorageAvailable: function () {
    try {
      var k = "__f2r_probe__";
      window.localStorage.setItem(k, "1");
      window.localStorage.removeItem(k);
      return 1;
    } catch (e) { return 0; }
  },
  F2R_PageActive: function () {
    try {
      if (document.hidden) return 0;
      if (typeof document.hasFocus === "function" && !document.hasFocus()) return 0;
      return 1;
    } catch (e) { return 1; }
  }
});
